/* OpenXlist - Copyright (c) 2013 Renishaw plc. All rights reserved.
 *
 * Sample program to show how to open a WDF file and open the XList data
 */

#include <wdfapi.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#pragma comment(lib, "wdf")


void GetXList(WDF_HANDLE wdf, WdfHeader hdr);
void GetYList(WDF_HANDLE wdf, WdfHeader hdr);

/*
*   Opens WDF File and header and then calls an appropriate function to extract data from said file
*/
int main(int argc, char *argv[])
{
    WDF_HANDLE wdf = NULL;
    WdfHeader hdr = {0};
    WDF_STATUS status = WDF_OK;

    if (argv[1])
    {
        char * file = argv[1];

        // Open the WDF file
        status = Wdf_OpenA(file, "r", &wdf);    //use Wdf_OpenA for narrow characters and Wdf_Open for wide characters
        if (WDF_SUCCESS(status))
        {
            // Get Header
            status = Wdf_GetHeader(wdf, &hdr);
            if (WDF_SUCCESS(status))
            {
                GetXList(wdf, hdr);
                GetYList(wdf, hdr);
            }

            Wdf_Close(wdf);
        }
    }
    return WDF_SUCCESS(status) ? 0 : 1;
}

// Extracts X List data from WDF
void GetXList(WDF_HANDLE wdf, WdfHeader hdr)
{
    uint32_t n = 0;
    float * data = new float[hdr.npoints];

    // Get X-list data
    /*
     * Wdf_GetXList(WDF_HANDLE wdf, int start, int end, float* dataptr)
     * wdf: handle to wdf to get xlist from
     * start: the 0 based index to load Xlist data from. 
     * end: the 0 based index to stop collecting data (pass in -1 to indicate stop at the end).
     * dataptr: pointer to a float array to return the data to.
     */
    Wdf_GetXList(wdf, 0, hdr.npoints - 1, data);

    // Print X list data
    printf("XList:\n");
    for (n = 0; n < hdr.npoints; ++n)
    {
        printf("%f\n", data[n]);
    }

    delete [] data;
}

void GetYList(WDF_HANDLE wdf, WdfHeader hdr)
{
    uint32_t n=0;
    float *data = new float[hdr.ylistcount];

    //Get Y-List data
    /*
     * Wdf_GetXList(WDF_HANDLE wdf, int start, int end, float* dataptr)
     * wdf: handle to wdf to get ylist from
     * start: the 0 based index to load Ylist data from. 
     * end: the 0 based index to stop collecting data (pass in -1 to indicate stop at the end).
     * dataptr: pointer to a float array to return the data to.
     */
    Wdf_GetYList(wdf, 0, hdr.ylistcount-1, data);

    //Print Y list data
    printf("YList:\n");
    for (n=0; n<hdr.ylistcount; n++)
    {
        printf("%f\n", data[n]);
    }

    delete [] data;
}

