/* wdf_props.c - Copyright (c) 2011 Renishaw plc. All rights reserved.
 *
 * Sample program to read the properties for a WDF file and print them to
 * standard output.
 *
 * Compile with:
 *   cl -nologo -W3 -MDd -Zi -Od -I..\include wdf_props.c \
 *       -link -subsystem:console -libpath:..\Release wdf.lib
 */

#if defined(UNICODE) && !defined(_UNICODE)
#define _UNICODE
#endif
#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wdfapi.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <tchar.h>

typedef struct State {
    int count;
    LPTSTR prefix;
    WDF_PSET topmost;
} State;

static WDF_STATUS
onProperty(WDF_PSET pset, WDF_PROPERTY prop, void *clientData)
{
    static int count = 0;
    SYSTEMTIME st;
    State *statePtr = clientData;
    uint32_t n;
    TCHAR sz[80] = {0};
    int is_array = (prop->hdr.flags & 0x80) == 0x80;
    Wdf_GetPropertyName(pset, prop, sz, 80);
    _tprintf(_T("%s% 4d %c 0x%04x %-12.12s "),
             statePtr->prefix, ++statePtr->count, prop->hdr.type, prop->hdr.key, sz);
    if (is_array) { _tprintf(_T("[%d:"), prop->length); }
    switch (prop->hdr.type)
    {
        case '?': _tprintf(_T("%s"), (prop->val.boolVal != 0) ? "true" : "false"); break;
        case 'c': _tprintf(_T("%d"), (int)prop->val.cVal); break;
        case 's': _tprintf(_T("%hd"), prop->val.hVal); break;
        case 'i': _tprintf(_T("%ld"), prop->val.lVal); break;
        case 'w': _tprintf(_T("%I64d"), prop->val.llVal); break;
        case 'r':
            if (is_array) {
                for (n = 0; n < prop->length && n < 6; n++)
                    _tprintf(_T(" %.2f"), prop->val.fltVec[n]);
                if (n < prop->length) _tprintf(_T(" ..."));
            } else {
                _tprintf(_T("%f"), prop->val.fltVal);
            }
            break;
        case 'q':
            if (is_array) {
            } else {
                for (n = 0; n < prop->length && n < 6; n++)
                    _tprintf(_T(" %.6lf"), prop->val.fltVec[n]);
                if (n < prop->length) _tprintf(_T(" ..."));
                _tprintf(_T("%lf"), prop->val.dblVal);
            }
            break;
        case 't':
        {
            FileTimeToSystemTime((const FILETIME *)&prop->val.timeVal, &st);
            _tprintf(_T("%04hd-%02hd-%02hdT%02hd:%02hd:%02hd.%hd"),
                     st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
            break;
        }
        case 'u':
        {
            wchar_t *wsz;
            int cch = MultiByteToWideChar(CP_UTF8, 0, prop->val.strVal, prop->length, NULL, 0);
            wsz = (wchar_t *)malloc(sizeof(wchar_t) * (cch + 1));
            cch = MultiByteToWideChar(CP_UTF8, 0, prop->val.strVal, prop->length, wsz, cch+1);
            wsz[cch] = 0;
            wprintf(L"%s", wsz);
            free(wsz);
            break;
        }
        case 'b':
        {
            _tprintf(_T("%lu bytes "), prop->length);
            if (prop->length < 16) {
                uint32_t n;
                for (n = 0; n < prop->length; ++n) {
                    _tprintf(_T("%02x"), prop->val.strVal[n]);
                }
            }
            break;
        }
        case 'p':
        {
            WDF_PSET child;
            WDF_STATUS status;
            State state;
            size_t cbprefix = (_tcslen(statePtr->prefix) + 3) * sizeof(TCHAR);
            state.count = 0;
            state.topmost = statePtr->topmost;
            state.prefix = (LPTSTR)malloc(cbprefix);
#if _MSC_VER >= 1500
            _tcscpy_s(state.prefix, cbprefix, statePtr->prefix);
            _tcscat_s(state.prefix, cbprefix, _T("  "));
#else
            _tcscpy(state.prefix, statePtr->prefix);
            _tcscat(state.prefix, _T("  "));
#endif
            _tprintf(_T("{\n"));
            status = Wdf_OpenChildPropertySet(state.topmost, prop, &child);
            if (SUCCEEDED(status)) {
                status = Wdf_EnumProperties(child, onProperty, &state);
                Wdf_ClosePropertySet(child);
            }
            if (status != WDF_OK) {
                _ftprintf(stderr, _T("failed to open child property\n"));
                exit(1);
            }
            _tprintf(_T("%s   }"), statePtr->prefix);
            free(state.prefix);
        }
    }
    _tprintf(_T("%s\n"), ((prop->hdr.flags & 0x80) == 0x80)?_T("]"):_T(""));
    return WDF_OK;
}

int
_tmain(int argc, TCHAR *argv[])
{
    WDF_HANDLE wdf = NULL;
    WdfHeader hdr;
    WDF_STATUS status = WDF_OK;
    uint32_t section = WDF_BLOCKID_WIREDATA;
    uint32_t uid = WDF_BLOCKID_ANY;
    char sz[5] = {0};

    if (argc < 2 || argc > 4) {
        _tprintf(_T("usage: wdf_props filename ?section? ?uid?\n"));
        return 1;
    }

    if (argc == 4) {
        uid = _tcstoul(argv[3], NULL, 0);
    }

    if (argc >= 3) {
        if (_tcslen(argv[2]) != 4) {
            _tprintf(_T("error: invalid section paramater. Must be 4 chars\n"));
            return 1;
        }
#ifdef UNICODE
        wcstombcs(sz, argv[2], 4);
#else
        strncpy(sz, argv[2], 4);
#endif
        section = *(uint32_t *)sz;
    }

    status = Wdf_Open(argv[1], _T("r"), &wdf);
    if (WDF_SUCCESS(status)) {

        status = Wdf_GetHeader(wdf, &hdr);
        if (WDF_SUCCESS(status)) {

            WDF_STREAM stream;
            WDF_PSET pset;
            WdfBlock block = {0};

            status = Wdf_OpenSection(wdf, section, uid, &stream, &block);
            if (WDF_SUCCESS(status))
            {
                WdfBlock block2 = {0};
                uint32_t pset_size = 0;
                int cb = 0;
                /* read the PSET marker if present, then the pset stream size */
                status = Wdf_Read(stream, &pset_size, sizeof(uint32_t), &cb);
                if (WDF_SUCCESS(status) && pset_size == WDF_STREAM_IS_PSET)
                    status = Wdf_Read(stream, &pset_size, sizeof(uint32_t), &cb);
                if (WDF_SUCCESS(status))
                    status = Wdf_OpenPropertySet(stream, pset_size, &pset);
                if (WDF_SUCCESS(status))
                {
                    State state;
                    state.count = 0;
                    state.prefix = _T("");
                    state.topmost = pset;
                    status = Wdf_EnumProperties(pset, onProperty, &state);
                    Wdf_ClosePropertySet(pset);
                }
                Wdf_CloseStream(stream);
            }
            if (!WDF_SUCCESS(status))
                _tprintf(_T("error: %08x\n"), status);
        }

        Wdf_Close(wdf);
    }
    return WDF_SUCCESS(status) ? 0 : 1;
}
