/**
 * @file wdf.h
 * @brief Structures and field definitions used in Renishaw WDF spectral data files.
 * @version 1.0
 * @author Copyright (c) 2011 Renishaw plc. All rights reserved.
 *
 * A WDF file is a sequence of blocks. Each block starts with a 16 byte
 * header of type WdfBlock that contains a block type id, a unique id and
 * the size of the block header plus its data. The content of any block
 * depends on the block type. For the first (file) block, it is made up of
 * WdfHeader structure described below (which includes its block header as
 * the first 16 bytes). For the DATA block the spectral data is stored
 * as a sequence of 32bit IEEE floating-point numbers in Intel (little-
 * endian) byte order. See the accompanying documentation for the layout
 * of any other blocks.
 *
 * The majority of the blocks in a wdf file will contain key:value collections
 * known as property sets (or psets). The presence of a pset is indicated by
 * a marker immediately following the block header 'PSET'. This is followed by
 * number of bytes used by the pset serialization as a uint32_t. The byte count does
 * not include the PSET marker or the pset size. Some blocks that have an initial
 * PSET may have additional data following the pset data. In such cases the block
 * size will be 
 *  (sizeof(WdfBlock) + (2 * sizeof(uint32_t)) + pset_size + additional_data_size)
 */

#ifndef wdf_h_INCLUDE
#define wdf_h_INCLUDE

#if defined(__cplusplus)
extern "C" {
#endif

#if defined(_MSC_VER) && _MSC_VER < 1600
typedef signed   __int8   int8_t;
typedef unsigned __int8  uint8_t;
typedef signed   __int16  int16_t;
typedef unsigned __int16 uint16_t;
typedef signed   __int32  int32_t;
typedef unsigned __int32 uint32_t;
typedef signed   __int64  int64_t;
typedef unsigned __int64 uint64_t;
#else
#include <stdint.h>
#endif
typedef unsigned char utf8_t;

#define WDF_FILE_VERSION 1      /**< current file version number */

typedef struct WdfBlock {
    uint32_t id;
    uint32_t uid;
    uint64_t size;
} WdfBlock;

typedef enum WdfFlags {
    WdfXYXY = (1 << 0),               /**< Multiple X list and data blocks exist */
    WdfChecksum = (1 << 1),           /**< checksum is enabled */
    WdfCosmicRayRemoval = (1 << 2),   /**< hardware cosmic ray removal was enabled */
    WdfMultitrack = (1 << 3),         /**< separate x-list for each spectrum */
    WdfSaturation = (1 << 4),         /**< saturated datasets exist */
    WdfFileBackup = (1 << 5),         /**< a complete backup file has been created */
    WdfTemporary = (1 << 6),          /**< this is a temporary file set for Display Title else filename */
    WdfSlice = (1 << 7),              /**Indicates that file has been extracted from WdfVol file slice like X / Y / Z. **/
} WdfFlags;

/**
 * Spectrum flags are set per-spectrum and are recorded in the flags data origin list.
 * The high 32 bits of the flags value is used for an error code leaving the low
 * 32 bits for use with the following flag values.
 */
typedef enum WdfSpectrumFlags {
    WdfSpectrumFlag_Saturated = (1 << 0), /**< Saturation flag. Some part of the spectrum data was saturated */
    WdfSpectrumFlag_Error = (1 << 1),     /**< Error flag. An error occurred while collecting this spectrum */
    WdfSpectrumFlag_CosmicRay = (1 << 2), /**< Cosmic ray flag. A cosmic ray was detected and accepted in software */
} WdfSpectrumFlags;

/**
 * The WdfScanType describes the data collection method used; this flag does not 
 *  necessarily reflect the format of the data in the file.
 */
typedef enum WdfScanType {
    WdfScanType_Unspecified        = 0x0000,    /**< for data that does not represent a spectrum collected from a Renishaw system */
    WdfScanType_Static             = 0x0001,    /**< for single readout off the detector. Can be spectrum or image */
    WdfScanType_Continuous         = 0x0002,    /**< for readouts using continuous extended scanning. Can be spectrum or image
                                                    (unlikely; impossible for x axis readout) */
    WdfScanType_StepRepeat         = 0x0003,    /**< for multiple statics taken at slightly overlapping ranges, then 'stitched'
                                                    together to a single extended spectrum. Can be spectrum or image (unlikely) */
    WdfScanType_FilterScan         = 0x0004,    /**< filter image and filter scan both supported purely for historical reasons */
    WdfScanType_FilterImage        = 0x0005,
    WdfScanType_StreamLine         = 0x0006,    /**< must be a WdfType_Map measurement */
    WdfScanType_StreamLineHR       = 0x0007,    /**< must be a WdfType_Map measurement */
    WdfScanType_Point              = 0x0008,    /**< for scans performed with a point detector */

    /* The values below for multitrack and linefocus are flags that can be ORed with the above integer values
     *  - multitrack discrete on fixed grating systems will only be static
     *  - multitrack discrete could, on a fibre-probe system, be continuous, stitched, or static
     *  - linefocusmapping similarly couild be continuous, stitched, or static, but at time of writing is static
     */
    WdfScanType_MultitrackStitched = 0x0100,    /**< result is not a multitrack file */
    WdfScanType_MultitrackDiscrete = 0x0200,    /**< result is multitrack file (wdf header has multitrack flag set).*/
    WdfScanType_LineFocusMapping   = 0x0400,    /**< Could be Static, Continuous (not yet implemented, impossible for x axis
                                                   readout), or StepAndRepeat (not yet implemented) */
} WdfScanType;

/**
 * The WdfType describes the measurement type; namely single collection,
 *  a series of data, or a map (which can be 2D or 3D).
 */
typedef enum WdfType {
    WdfType_Unspecified = 0,
    WdfType_Single      = 1,    /**< file contains a single spectrum */
    WdfType_Series      = 2,    /**< file contains multiple spectra with one common data origin (time, depth, temperature etc) */
    WdfType_Map         = 3,    /**< file contains multiple spectra with more that one common data origin. Typically area maps
                                   use X and Y spatial origins. Volume maps use X, Y and Z. The WMAP block normally defines the
                                   physical region.obeys the maparea object. check scan type for streamline, linefocus, etc. */
} WdfType;

/**
 * Data type definitions.
 * These are used to declare the type of data stored in data origin lists.
 * Note: only 15 bits are used for the type, the topmost bit is a flag that indicates
 * an important origin (set) or an alternative origin (unset).
 */
#define WDF_ORIGIN_IS_ALTERNATE(x) (((x) & 0x80000000) == 0x00000000)
#define WDF_ORIGIN_TYPE_VALUE(x) ((x) & 0x7fffffff)
#define WDF_ORIGIN_TYPE_IS_CUSTOM(x) (((x) & 0x40000000) == 0x40000000)

typedef enum WdfDataType {
    WdfDataType_Arbitrary,      /**< arbitrary type */
    WdfDataType_Spectral,       /**< DEPRECATED: Use Frequency instead (spectral data type) */
    WdfDataType_Intensity,      /**< intensity */
    WdfDataType_Spatial_X,      /**< X position */
    WdfDataType_Spatial_Y,      /**< Y axis position */
    WdfDataType_Spatial_Z,      /**< Z axis (vertical) position */
    WdfDataType_Spatial_R,      /**< rotary stage R axis position */
    WdfDataType_Spatial_Theta,  /**< rotary stage theta angle */
    WdfDataType_Spatial_Phi,    /**< rotary stage phi angle */
    WdfDataType_Temperature,    /**< temperature */
    WdfDataType_Pressure,       /**< pressure */
    WdfDataType_Time,           /**< time */
    WdfDataType_Derived,        /**< derivative type */
    WdfDataType_Polarization,   /**< polarization */
    WdfDataType_FocusTrack,     /**< focus track Z position */
    WdfDataType_RampRate,       /**< temperature ramp rate */
    WdfDataType_Checksum,       /**< spectrum data checksum */
    WdfDataType_Flags,          /**< bit flags */
    WdfDataType_ElapsedTime,    /**< elapsed time intervals */
    WdfDataType_Frequency,      /**< frequency */
    
    //Microplate mapping origins
    WdfDataType_Mp_Well_Spatial_X,
    WdfDataType_Mp_Well_Spatial_Y,
    WdfDataType_Mp_LocationIndex,
    WdfDataType_Mp_WellReference,

    WdfDataType_EndMarker       /* THIS SHOULD ALWAYS BE LAST */
} WdfDataType;

typedef enum WdfDataUnits {
    WdfDataUnits_Arbitrary,    /**< arbitrary units */
    WdfDataUnits_RamanShift,   /**< Raman shift (cm-1) */
    WdfDataUnits_Wavenumber,   /**< wavenumber (nm) */
    WdfDataUnits_Nanometre,    /**< 10-9 metres (nm) */
    WdfDataUnits_ElectronVolt, /**< electron volts (eV) */
    WdfDataUnits_Micron,       /**< 10-6 metres (um) */
    WdfDataUnits_Counts,       /**< counts */
    WdfDataUnits_Electrons,    /**< electrons */
    WdfDataUnits_Millimetres,  /**< 10-3 metres (mm) */
    WdfDataUnits_Metres,       /**< metres (m) */
    WdfDataUnits_Kelvin,       /**< degrees Kelvin (K) */
    WdfDataUnits_Pascal,       /**< Pascals (Pa) */
    WdfDataUnits_Seconds,      /**< seconds (s) */
    WdfDataUnits_Milliseconds, /**< 10-3 seconds (ms) */
    WdfDataUnits_Hours,
    WdfDataUnits_Days,
    WdfDataUnits_Pixels,
    WdfDataUnits_Intensity,
    WdfDataUnits_RelativeIntensity,
    WdfDataUnits_Degrees,
    WdfDataUnits_Radians,
    WdfDataUnits_Celcius,
    WdfDataUnits_Farenheit,
    WdfDataUnits_KelvinPerMinute,
    WdfDataUnits_FileTime,     /**< date-time expressed as a Windows FILETIME */
    WdfDataUnits_EndMarker
} WdfDataUnits;

typedef struct WdfVector {
    uint32_t x;
    uint32_t y;
    uint32_t z;
} WdfVector;

typedef struct WdfRealVector {
    float x;
    float y;
    float z;
} WdfRealVector;

typedef struct WdfRealVector WdfLocation;

typedef enum WdfMapAreaFlags {
    WdfMapArea_RandomPoints = (1 << 0),     /**< default is rectangle area */
    WdfMapArea_ColumnMajor = (1 << 1),      /* default is X first then Y. */
    WdfMapArea_Alternating = (1 << 2),      /* raster or snake */
    WdfMapArea_LineFocusMapping = (1 << 3), /* see also linefocus_height */
    // The following two values are deprecated; negative step-size is sufficient information.
    // [Deprecated] WdfMapArea_InvertedRows = (1 << 4),     /* true if rows collected right to left */
    // [Deprecated] WdfMapArea_InvertedColumns = (1 << 5),  /* true if columns collected bottom to top */
    WdfMapArea_SurfaceProfile = (1 << 6),   /* true if the Z data is non-regular (surface maps) */
    WdfMapArea_XyLine = (1 << 7),           /* line or depth slice forming a single line along the XY plane:
                                               length.x contains number of points along line; length.y = 1 */
} WdfMapAreaType;

/**
 * Data structure used for the WMAP block to hold information about
 * the sample region selected for mapping.
 * 
 * For regular rectangle maps, we define the initial position, step
 * size and number of points for each direction. If the count for any
 * direction is 0 then that dimension was undefined and we have a
 * plane.
 *
 * For irregular areas the sample positions are read from the data
 * origin lists and this structure only contains the bounding box of
 * the sample region used. In this case the @ref WdfMapArea_RandomPoints
 * flag is set, the step size will be the size of the area and the count
 * will be 1. ie: there was 1 point and it is a whole area away from the
 * initial point - thus defining the bounding box.
 *
 * For linefocus mapping collections, the data collection order is
 * semi-regular and we set the @ref WdfMapArea_LineFocusMapping flags
 * to indicate this mode.  In this case a single ccd image is
 * converted into a number of spectra at each physical acquisition
 * point. The lf_size field is set to the number of spectra produced
 * together. The length field contains the full number of points in
 * each axis and vector field contains the step size between each
 * spectrum. The result is that data is collected in the y direction
 * for lf_size spectra, then the next lf_size are collected from the
 * subsequent column in the X direction. The stage moves (vector.y *
 * lf_size microns in the y direction).
 */

typedef struct WdfMapAreaBlock {
    struct WdfBlock block; /* standard block header fields */
    uint32_t flags;        /**< Set of flags from the WdfMapAreaFlags enumeration */
    uint32_t unused;       /* not used by WiRE */
    WdfLocation location;  /**< initial position */
    WdfRealVector vector;  /**< step size */
    WdfVector length;      /**< number of points */
    uint32_t lf_size;      /**< line focus region in number of spectra */
} WdfMapAreaBlock;

/*
 * Block identity values
 * Renishaw will only use uppercase letter values. Third-parties may
 * define their own block ids but should use lower-case letter values.
 */

#define WDF_BLOCKID_FILE         0x31464457UL /* 'W' 'D' 'F' '1' */
#define WDF_BLOCKID_DATA         0x41544144UL /* 'D' 'A' 'T' 'A' */
#define WDF_BLOCKID_YLIST        0x54534c59UL /* 'Y' 'L' 'S' 'T' */ 
#define WDF_BLOCKID_XLIST        0x54534c58UL /* 'X' 'L' 'S' 'T' */
#define WDF_BLOCKID_ORIGIN       0x4e47524fUL /* 'O' 'R' 'G' 'N' */
#define WDF_BLOCKID_COMMENT      0x54584554UL /* 'T' 'E' 'X' 'T' */
#define WDF_BLOCKID_WIREDATA     0x41445857UL /* 'W' 'X' 'D' 'A' */
#define WDF_BLOCKID_DATASETDATA  0x42445857UL /* 'W' 'X' 'D' 'B' */
#define WDF_BLOCKID_MEASUREMENT  0x4d445857UL /* 'W' 'X' 'D' 'M' */
#define WDF_BLOCKID_CALIBRATION  0x53435857UL /* 'W' 'X' 'C' 'S' */
#define WDF_BLOCKID_INSTRUMENT   0x53495857UL /* 'W' 'X' 'I' 'S' */
#define WDF_BLOCKID_MAPAREA      0x50414d57UL /* 'W' 'M' 'A' 'P' */
#define WDF_BLOCKID_WHITELIGHT   0x4c544857UL /* 'W' 'H' 'T' 'L' */
#define WDF_BLOCKID_THUMBNAIL    0x4c49414eUL /* 'N' 'A' 'I' 'L' */
#define WDF_BLOCKID_MAP          0x2050414dUL /* 'M' 'A' 'P' ' ' */
#define WDF_BLOCKID_CURVEFIT     0x52414643UL /* 'C' 'F' 'A' 'R' */
#define WDF_BLOCKID_COMPONENT    0x534c4344UL /* 'D' 'C' 'L' 'S' */
#define WDF_BLOCKID_PCA          0x52414350UL /* 'P' 'C' 'A' 'R' */
#define WDF_BLOCKID_EM           0x4552434dUL /* 'M' 'C' 'R' 'E' */
#define WDF_BLOCKID_ZELDAC       0x43444c5aUL /* 'Z' 'L' 'D' 'C' */
#define WDF_BLOCKID_RESPONSECAL  0x4c414352UL /* 'R' 'C' 'A' 'L' */
#define WDF_BLOCKID_CAP          0x20504143UL /* 'C' 'A' 'P' ' ' */
#define WDF_BLOCKID_PROCESSING   0x50524157UL /* 'W' 'A' 'R' 'P' */
#define WDF_BLOCKID_ANALYSIS     0x41524157UL /* 'W' 'A' 'R' 'A' */
#define WDF_BLOCKID_SPECTRUMLABELS 0x4C424C57UL/*'W' 'L' 'B' 'L' */
#define WDF_BLOCKID_CHECKSUM     0x4b484357UL /* 'W' 'C' 'H' 'K' */
#define WDF_BLOCKID_RXCALDATA    0x44435852UL /* 'R' 'X' 'C' 'D' */
#define WDF_BLOCKID_RXCALFIT     0x46435852UL /* 'R' 'X' 'C' 'F' */
#define WDF_BLOCKID_XCAL         0x4C414358UL /* 'X' 'C' 'A' 'L' */
#define WDF_BLOCKID_SPECSEARCH   0x48435253UL /* 'S' 'R' 'C' 'H' */
#define WDF_BLOCKID_TEMPPROFILE  0x504d4554UL /* 'T' 'E' 'M' 'P' */
#define WDF_BLOCKID_UNITCONVERT  0x56434e55UL /* 'U' 'N' 'C' 'V' */
#define WDF_BLOCKID_ARPLATE      0x52505241UL /* 'A' 'R' 'P' 'R' */
#define WDF_BLOCKID_ELECSIGN     0x43454c45UL /* 'E' 'L' 'E' 'C' */
#define WDF_BLOCKID_BKXLIST      0x4c584b42UL /* 'B' 'K' 'X' 'L' */
#define WDF_BLOCKID_AUXILARYDATA 0x20585541UL /* 'A' 'U' 'X' ' ' */                 
#define WDF_BLOCKID_CHANGELOG    0x474c4843UL /* 'C' 'H' 'L' 'G' */
#define WDF_BLOCKID_SURFACE      0x46525553UL /* 'S' 'U' 'R' 'F' */

#define WDF_BLOCKID_ANY          0xffffffffUL /* reserved value for @ref Wdf_FindSection */ 

#define WDF_STREAM_IS_PSET    0x54455350UL /* 'P' 'S' 'E' 'T' */

typedef struct WdfHeader {
    /*   0 */ uint32_t signature;   /* Magic number to check that this is a WDF file (WDF_BLOCKID_FILE) */
    /*   4 */ uint32_t version;     /* The version of this specification used by this file. */
    /*   8 */ uint64_t size;        /* The size of this block (512 bytes) */
    /*  16 */ uint64_t flags;       /* Flags from the WdfFlags enumeration */
    /*  24 */ uint32_t uuid[4];     /* a file unique identifier - never changed once allocated */
    /*  40 */ uint64_t unused0;
    /*  48 */ uint32_t unused1;
    /*  52 */ uint32_t ntracks;     /* if WdfXYXY flag is set - contains the number of tracks used */
    /*  56 */ uint32_t status;      /* file status word (error code) */
    /*  60 */ uint32_t npoints;     /* number of points per spectrum */
    /*  64 */ uint64_t nspectra;    /* number of actual spectra (capacity) */
    /*  72 */ uint64_t ncollected;  /* number of spectra written into the file (count) */
    /*  80 */ uint32_t naccum;      /* number of accumulations per spectrum */
    /*  84 */ uint32_t ylistcount;  /* number of elements in the y-list (>1 for image) */
    /*  88 */ uint32_t xlistcount;  /* number of elements for the x-list */
    /*  92 */ uint32_t origincount; /* number of data origin lists */
    /*  96 */ utf8_t   appname[24];   /* application name (utf-8 encoded) */
    /* 120 */ uint16_t appversion[4]; /* application version (major,minor,patch,build) */
    /* 128 */ uint32_t scantype;    /* scan type - WdfScanType enum  */
    /* 132 */ uint32_t type;        /* measurement type - WdfType enum  */
    /* 136 */ uint64_t time_start;  /* collection start time as FILETIME */
    /* 144 */ uint64_t time_end;    /* collection end time as FILETIME */
    /* 152 */ uint32_t units;       /* spectral data units (one of WdfDataUnits) */
    /* 156 */ float    laserwavenum;/* laser wavenumber */
    /* 160 */ uint64_t spare[6];
    /* 208 */ utf8_t   user[32];    /* utf-8 encoded user name */
    /* 240 */ utf8_t   title[160];  /* utf-8 encoded title */
    /* 400 */ uint64_t padding[6];  /* padded to 512 bytes */
    /* 448 */ uint64_t free[4];     /* available for third party use */
    /* 480 */ uint64_t reserved[4]; /* reserved for internal use by WiRE */
} WdfHeader;


#if defined(__cplusplus)
}
#endif
#endif /* wdf_h_INCLUDE */
