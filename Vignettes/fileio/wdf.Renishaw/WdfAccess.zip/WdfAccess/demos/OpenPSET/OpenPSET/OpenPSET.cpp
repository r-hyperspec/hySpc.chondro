/* OpenPSET - Copyright (c) 2013 Renishaw plc. All rights reserved.
*
* Sample program to show how to open a WDF file and open the PSET
*/

#include <wdfapi.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#pragma comment(lib, "wdf")

void GetPSET(WDF_STREAM stream);
void CreatePSET();

int main()
{
    WDF_HANDLE handle=NULL;
    WdfHeader hdr = {0};
    WDF_STATUS status = Wdf_Open(L"example.wdf", L"r", &handle);
    if (WDF_SUCCESS(status))
    {
        WDF_STREAM stream;
        WdfBlock block;
        status = Wdf_OpenSection(handle, WDF_BLOCKID_WIREDATA, WDF_BLOCKID_ANY, &stream, &block);
        if (WDF_SUCCESS(status))
        {
            GetPSET(stream);
        }
        Wdf_Close(handle);
    }
    return WDF_OK;
}
/*
 * Opens a pset in a block stream,
 * and retrieves an item from the pset
 */
void GetPSET(WDF_STREAM stream)
{
    uint32_t magic;
    //Reads the magic number indicating a pset first
    WDF_STATUS status = Wdf_Read(stream, &magic, sizeof(magic), NULL);
    if (WDF_SUCCESS(status) && (magic == WDF_STREAM_IS_PSET))
    {
        //REads the length of the pset
        uint32_t len = 0;
        status = Wdf_Read(stream, &len, sizeof(len), NULL);
        if (WDF_SUCCESS(status))
        {
            WDF_PSET phandle;
            //Opens the property set when the stream pointer is at the beginning of the property set.
            /* 
             * Wdf_OpenPropertySet(WDF_STREAM stream, uin64_t size, WDF_PSET* pset)
             * WDF_STREAM stream: wdf stream containing the pset
             * WDF_PSET* pHandle: pointer to the pset handle to be returned 
             */
            status = Wdf_OpenPropertySet(stream, len, &phandle);
            if (WDF_SUCCESS(status))
            {
                WDF_PROPERTY prop;
                //Gets the property item with key "Key"
                status = Wdf_GetPropertyItem(phandle, L"PropertyKey", &prop);
                if (prop->hdr.type == 'p')
                {
                    printf("The PropertyKey property is another property set!");
                }
                Wdf_ClosePropertySet(phandle);
            }
        }
    }
}

//Not called in main, simply demonstrates creating a pset
void CreatePSET()
{
    WDF_PSET pset;
    //Creates a new pset and returns a handle to it as an argument
    WDF_STATUS status = Wdf_CreatePropertySet(&pset);
    if (WDF_SUCCESS(status))
    {
        //Creates a float entry in pset with the specified key
        status = Wdf_SetPropertyItemFloat(pset, L"PropertyKey", 7.0);
        if (WDF_SUCCESS(status))
        {
            WDF_PSET childPset;
            status = Wdf_CreatePropertySet(&childPset);
            if (WDF_SUCCESS(status))
            {
                //creates a bool entry in pset
                status = Wdf_SetPropertyItemBool(childPset, L"PropertyKey2", true);
                if (WDF_SUCCESS(status))   
                {
                    //Set a property set as a member of another property set
                    status = Wdf_SetPropertyItemPset(pset, L"PsetKey", childPset);
                }
                Wdf_ClosePropertySet(childPset);
            }
        }
        //Always close psets once they have been finished with.
        Wdf_ClosePropertySet(pset);
    }
}