﻿/* 
 * OpenData - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * This demo shows how to open a .wdf file and extract the data block
 * containing spectral data using C#
 * 
 * Ensure that WiREDataFormats.dll has been referenced. Create a variable of
 * type WdfFile with parameters for file name and access rights. In this demo
 * the file name is taken from the first command line argument.
 * 
 * Use the WdfFile variable to return an array containing the spectral data.
 * The parameters of the GetSpectrum() function can be used to determine which
 * spectra are called
 */

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;        // Make sure to add a reference to WiREDataFormats.dll

namespace OpenData
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string fileName = args[0];
                using (WdfFile file = new WdfFile(fileName, WdfFileAccess.ReadOnly))
                {
                    WdfSpectrumCollection specCollection = file.SpectrumCollection;
                    long length = specCollection.XListLength;
                    float[] data = new float[length];

                    // GetSpectrum reads data from the chosen spectrum
                    // First parameter is the zero-based index of the spectrum
                    // Second parameter returns the selected spectral data
                    specCollection.GetSpectrum(0, data);

                    for (int i = 0; i < length; i++)
                    {
                        Console.WriteLine(data[i]);
                    }
                }
            }
        }
    }
}
