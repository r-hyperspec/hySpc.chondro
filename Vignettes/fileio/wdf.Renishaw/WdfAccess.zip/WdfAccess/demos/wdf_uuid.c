#ifndef UNICODE
#define UNICODE
#endif
#if defined(UNICODE) && !defined(_UNICODE)
#define _UNICODE
#endif
#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <ole2.h>
#include <stdlib.h>
#include <string.h>
#include <wdfapi.h>
#include <tchar.h>

#if _MSC_VER >= 100
#  pragma comment(lib, "wdf")
#  pragma comment(lib, "ole32")
#  pragma comment(lib, "oleaut32")
#endif

int
_tmain(int argc, TCHAR *argv[])
{
    WDF_STATUS status = WDF_OK;
    WDF_HANDLE wdf = NULL;
    WdfHeader hdr = {0};

    if (argc != 2) {
        _putts(_T("usage: wdf_uuid filename\n"));
        return 1;
    }
    
    status = Wdf_OpenW(argv[1], _T("r"), &wdf);
    if (WDF_SUCCESS(status))
    {
        status = Wdf_GetHeader(wdf, &hdr);
        if (WDF_SUCCESS(status))
        {
            HRESULT hr = S_OK;
            wchar_t *wsz = NULL;
            hr = StringFromCLSID((UUID *)&hdr.uuid, &wsz);
            if (SUCCEEDED(hr))
            {
                wprintf(L"uuid: %s\n", wsz);
                CoTaskMemFree(wsz);
            } else { _tprintf(_T("error: %#08x\n"), hr); }
        }
        Wdf_Close(wdf);
    } else {
        _tprintf(_T("error: failed to open file\n"));
        return 1;
    }
    return 0;
}
