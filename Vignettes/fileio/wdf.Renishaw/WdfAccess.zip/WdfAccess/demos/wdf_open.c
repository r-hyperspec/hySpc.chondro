/* wdf_open - Copyright (c) 2011 enishaw plc. All rights reserved.
 *
 * Sample program to show how to open a WDF file and iterate over all the
 * file sections
 */

#include <wdfapi.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

static const char *version = "4.0.0.1";

static void
usage()
{
    printf("usage: wdf_open [options] <filename>\n"
           "    --version         show version information\n"
           "    --spectrum index  print data for indicated spectrum\n");
}

static WDF_STATUS
sectionProc(WDF_HANDLE wdf, WdfBlock *blockPtr, void *clientData)
{
    char sz[5] = {0,0,0,0,0};
    memcpy(sz, &blockPtr->id, 4);
    printf("%s %d %I64u\n", sz, blockPtr->uid, blockPtr->size);
    return WDF_OK;
}

int
main(int argc, char *argv[])
{
    WDF_HANDLE wdf = NULL;
    WdfHeader hdr = {0};
    WDF_STATUS status = WDF_OK;
    int argi = 1, mode = 0;
    uint64_t spectrum = 0;

    for (argi = 1; argi < argc-1; ++argi) {
        if (strcmp("--spectrum", argv[argi]) == 0) {
            double d = strtod(argv[argi+1], NULL);
            spectrum = (uint64_t)d;
            mode = 1;
            ++argi;
        }
    }

    if (argi >= argc) {
        usage();
        return 1;
    }

    if (strcmp("--version", argv[argi]) == 0) {
        printf("wdf_open version %s\n", version);
        return 0;
    }

    status = Wdf_Open(argv[argi], "r", &wdf);
    if (WDF_SUCCESS(status)) {
        
        status = Wdf_GetHeader(wdf, &hdr);
        if (WDF_SUCCESS(status)) {
         
            if (mode) {
                uint32_t n = 0;
                float *data = (float *)malloc(hdr.npoints * sizeof(float));
                status = Wdf_SpectrumData(wdf, spectrum, 0, hdr.npoints - 1, data);
                if (WDF_SUCCESS(status)) {
                    for (n = 0; n < hdr.npoints; ++n)
                        printf("%f\n", data[n]);
                } else {
                    fprintf(stderr, "error: failed to read data\n");
                }
            } else {
                Wdf_EnumSections(wdf, sectionProc, NULL);
                printf("%I64u spectra of %u points\n", hdr.nspectra, hdr.npoints);
            }
        } else {
            fprintf(stderr, "error: failed to read header\n");
        }

        Wdf_Close(wdf);
    }
    return WDF_SUCCESS(status) ? 0 : 1;
}
