﻿/* 
 * OpenWDF - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * This demo shows how to open a .wdf file and read and write spectral data
 * 
 * Ensure that WiREDataFormats.dll has been referenced. Create a variable of
 * type WdfFile with parameters for file name and access rights.
 */

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace OpenWDF
{
    class Program
    {
        static void Main()
        {
            // Open WDF file and ensure that access is set to allow read and write
            using (WdfFile file = new WdfFile("example.wdf", WdfFileAccess.ReadAndAppend))
            {
                // Read out the first spectrum within the file
                long length = file.SpectrumCollection.XListLength;
                double[] data = new double[length];
                file.SpectrumCollection.GetSpectrum(0, data);

                // Write a new spectrum on the next index within the WDF file
                double[] dataToWrite = new double[length];
                file.SpectrumCollection.WriteSpectrum(1, dataToWrite);
            }
        }
    }
}
