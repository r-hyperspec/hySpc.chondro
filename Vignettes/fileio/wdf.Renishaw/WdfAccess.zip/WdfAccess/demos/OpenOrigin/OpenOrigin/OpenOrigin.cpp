/* OpenOrigin - Copyright (c) 2013 Renishaw plc. All rights reserved.
 *
 * Sample program to show how to open a WDF file and open the origin data
 */

#include <wdfapi.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#pragma comment(lib, "wdf")


void GetOriginData(WDF_HANDLE wdf, WdfHeader hdr, WdfDataType wdfType);

/*
*   Opens WDF File and header and then calls an appropriate function to extract data from said file
*/
int main(int argc, char *argv[])
{
    WDF_HANDLE wdf = NULL;
    WdfHeader hdr = {0};
    WDF_STATUS status = WDF_OK;

    if (argv[1])
    {
        char * file = argv[1];

        // Open the WDF file
        status = Wdf_OpenA(file, "r", &wdf);    //use Wdf_OpenA for narrow characters and Wdf_Open for wide characters
        if (WDF_SUCCESS(status))
        {
            // Get Header
            status = Wdf_GetHeader(wdf, &hdr);
            if (WDF_SUCCESS(status))
            {
                GetOriginData(wdf, hdr, WdfDataType_Spatial_X);
            }

            Wdf_Close(wdf);
        }
    }
    return WDF_SUCCESS(status) ? 0 : 1;
}

// Extracts Origin data of various types (change WdfDataType to control this)
void GetOriginData(WDF_HANDLE wdf, WdfHeader hdr, WdfDataType wdfType)
{
    uint32_t n = 0;
    double *data = new double[hdr.nspectra];
    /*
     * Wdf_GetOriginData(WDF_HANDLE wdf, WdfDataType type, int start, int end, double *dataptr)
     * WDF_HANDLE wdf: handle to the wdf file to open
     * WdfDataType type: data type of the origin (enum in wdf.h)
     * int start: 0 based index to start reading data from
     * int end: 0 based index to end reading data 
     * double *dataptr: pointer to double array to store the returned values
     */
    WDF_STATUS stat = Wdf_GetOriginData(wdf, wdfType, 0, static_cast<int>(hdr.nspectra)-1, data);

    // Print Origin list data
    for (n = 0; n < hdr.nspectra; n++)
    {
        printf("%f\n", data[n]);
    }

    delete [] data;
}