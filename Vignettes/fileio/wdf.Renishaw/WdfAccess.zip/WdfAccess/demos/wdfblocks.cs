//
// Example program that prints the wdf file block IDs and sizes
//
// Compile using:
//   csc /nologo /target:exe /r:WiREDataFormats.dll wdfblocks.cs

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace wdf2text
{
    public static class Program
    {
        public static int Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("usage: wdf2text filename");
                return 1;
            }

            using (WdfFile wdf = new WdfFile(args[0], WdfFileAccess.ReadOnly))
            {
                foreach (var section in wdf.EnumerateSections())
                {
                    Console.WriteLine("{0,-18} {1,3} {2}",
                        section.SectionType, section.SectionID, section.Length + 16);
                }
            }
            return 0;
        }
    }
}
