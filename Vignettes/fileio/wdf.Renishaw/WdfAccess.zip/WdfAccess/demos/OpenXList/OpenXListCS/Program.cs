﻿/* 
 * OpenXandYList - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * This demo shows how to open a .wdf file and extract the X and Y List data
 * using C#
 * 
 * Ensure that WiREDataFormats.dll has been referenced. Create a variable of
 * type WdfFile with parameters for file name and access rights. In this demo
 * the file name is taken from the first command line argument.
 * 
 * The WdfFile variable can be used to return an array of x or y list data
 * which can then be displayed, processed, etc.
 */

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;        // Make sure to add a reference to WiREDataFormats.dll

namespace OpenXandYList
{
    class Program
    {
        // Create a variable of type WdfFile
        // Call in your other functions which will read data from the WDF
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string fileName = args[0];
                using (WdfFile file = new WdfFile(fileName, WdfFileAccess.ReadOnly))
                {
                    // Open up x and y list data
                    float[] xdata, ydata;
                    file.SpectrumCollection.GetXListData(out xdata);
                    file.SpectrumCollection.GetYListData(out ydata);
                    int xlength = file.SpectrumCollection.XListLength;
                    int ylength = file.SpectrumCollection.YListLength;

                    // Print the data
                    Console.WriteLine("\r\n X data: \r\n");
                    for (int i = 0; i < xlength; i++)
                    {
                        Console.WriteLine(xdata[i]);
                    }

                    Console.WriteLine("\r\n Y data: \r\n");
                    for (int j = 0; j < ylength; j++)
                    {
                        Console.WriteLine(ydata[j]);
                    }
                }
            }
        }
    }
}
