﻿/* 
 * OpenPSET - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * This demo shows how to open a .wdf file and extract the PSET data using C#
 * 
 * Ensure that WiREDataFormats.dll has been referenced. Create a variable of
 * type WdfFile with parameters for file name and access rights. In this demo
 * the file name is taken from the first command line argument.
 * 
 * PSET data can be accessed from the WdfFile variable by first reading off the
 * magic number or by offsetting the binary reader by the length of the magic
 * number.
 * 
 * Ensure that the stream is set to the WdfSectionType containing the PSET data
 * of interest.
 */

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace OpenPSET
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string fileName = args[0];
                using (WdfFile file = new WdfFile(fileName, WdfFileAccess.ReadOnly))
                {
                    WdfSectionStream stream = file.OpenSection(WdfSectionAccess.ReadOnly, WdfSectionType.WiREData);

                    // Read magic number first

                    if (stream.CheckForPropertySetMarker())
                    {
                        byte[] lengthBytes = new byte[4];
                        stream.Read(lengthBytes, 0, 4);
                        int psetLength = BitConverter.ToInt32(lengthBytes, 0);

                        // Open and read PSET
                        WdfPropertySetReader propRead = new WdfPropertySetReader(stream, psetLength);
                        object target;
                        string propertyName = "ETA";

                        // Open and read property
                        bool bPropGet = propRead.TryGetItem(propertyName, out target);

                        if (bPropGet)
                        {
                            Console.WriteLine(target);
                        }
                    }
                }
            }
        }
        //This is not called in the program, it is here for demonstration purposes
        static void CreatePset(System.IO.Stream stream)
        {
            using (IWiREPropertySetWriter exportedPSet = new WdfPropertySetWriter())
            {
                //Inserts an item into the pset
                exportedPSet.SerializeItem("Label", "example Label");
                exportedPSet.SerializeItem("Description", "example");
                exportedPSet.SerializeItem("Time", DateTime.UtcNow);
                exportedPSet.SerializeItem("Operator", Environment.UserName);
                using (IWiREPropertySetWriter exportedNestedPSet = new WdfPropertySetWriter())
                {
                    exportedNestedPSet.SerializeItem("Item", "nested item example");
                    exportedPSet.SerializeItem("Properties", exportedPSet);
                }
                /*
                 * Writes the pset to a given stream. Can set the second argument to true if the user wishes to insert a pset marker magic number first.
                 */
                exportedPSet.WriteToStream(stream, false);
            }
        }
    }
}
