﻿/* 
 * OpenMap - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * This demo shows how to open a .wdf file and extract the map data using C#
 * 
 * Ensure that WiREDataFormats.dll has been referenced. Create a variable of
 * type WdfFile with parameters for file name and access rights. In this demo
 * the file name is taken from the first command line argument.
 * 
 * From the WdfFile variable a map block can be opened and read using
 * WdfbinaryReader. The data within the block may then be read out in order.
 */

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace OpenMap
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string fileName = args[0];
                using (WdfFile file = new WdfFile(fileName, WdfFileAccess.ReadOnly))
                {
                    WdfSpectrumCollection spectrum = file.SpectrumCollection;

                    // Open a map section from the wdf file into a stream
                    WdfSectionStream stream = file.OpenSection(WdfSectionAccess.ReadOnly, WdfSectionType.Map, 1);
                    WdfBinaryReader binRead = new WdfBinaryReader(stream);

                    // Read off the magic number
                    byte[] magic = new byte[4];
                    binRead.Read(magic, 0, 4);

                    // Open and read the PSET
                    byte[] sizePSET = new byte[4];
                    int psetLength = 0;
                    binRead.Read(sizePSET, 0, 4);
                    psetLength = BitConverter.ToInt32(sizePSET, 0);
                    WdfPropertySetReader propRead = new WdfPropertySetReader(stream, psetLength);
                    //Get critical items from pset
                    object type = propRead.GetItem("Type");
                    string strType = type.ToString();
                    object Time = propRead.GetItem("Time");
                    DateTime dt = (DateTime)Time;
                    object objVersion = propRead.GetItem("Version");
                    string strVersion = objVersion.ToString();
                    object objMapType = propRead.GetItem("MapType");
                    int iMapType = (int)objMapType;
                    object objDataList1 = propRead.GetItem("DataList0");
                    int iDataList1 = (int)objDataList1;
                    object objDataList2 = propRead.GetItem("DataList1");
                    int iDataList2 = (int)objDataList2;
                    object target;
                    propRead.TryGetItem("example", out target);
                    propRead.Dispose();

                    // Read the number of points
                    byte[] npoints = new byte[8];
                    binRead.Read(npoints, 0, 4);
                    System.UInt64 sizeNPoints = BitConverter.ToUInt64(npoints, 0);

                    // Read the map data
                    float[] data = new float[sizeNPoints];
                    binRead.ReadArray(data, 0, (int)(sizeNPoints));

                    for (int i = 0; i < (int)sizeNPoints; i++)
                    {
                        Console.WriteLine(data[i]);
                    }
                }
            }
        }
    }
}
