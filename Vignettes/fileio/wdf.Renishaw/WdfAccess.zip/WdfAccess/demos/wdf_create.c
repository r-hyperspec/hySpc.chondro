/* wdf_create - Copyright (c) 2011 Renishaw plc. All rights reserved.
 *
 * Sample program to show how to create a wdf file.
 * Note: as there is nothing Windows specific in this file this can
 *       also be used to check that the wdf.h header is platform
 *       independent. The program should compile on any platform.
 */

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#define snprintf _snprintf
#endif

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <io.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <wdf.h>

/*
 * Write a buffer at a specific offset in the file.
 */

static int
Write(int fd, uint64_t pos, void *data, size_t count)
{
    if (_lseeki64(fd, pos, SEEK_SET) == -1) {
        fprintf(stderr, "failed to seek to location %llu\n", pos);
    }
    return _write(fd, data, count);
}

/*
 * Get a FILETIME compatible value based on the start time
 * offset by 1 second per spectrum
 */

static uint64_t
GetTimestamp(int n)
{
    static time_t base = 0;
    if (base == 0) {
        base = time(NULL);
    }
    /* converts time_t to FILETIME */
    return ((base + n) * 10000000) + 116444736000000000;
}

/*
 * Generate spectral data (a noisy sine wave)
 * The size of the various spectra are passed via the WdfHeader structure
 * and this must match the buffer sizes passed here. Therefore ensure
 * that ylistcount and xlistcount and npoints are correct and used.
 */

static int
GetSpectrum(WdfHeader *hdrPtr, float *ylist, float *xlist, float *ilist)
{
    size_t n;
    const int npeaks = 3;
    static int factor = 1000;
    float interval = (npeaks * 2 * 3.1415f) / hdrPtr->npoints;
    for (n = 0; n < hdrPtr->ylistcount; ++n) {
        ylist[n] = 200.0f + n;
    }
    for (n = 0; n < (size_t)hdrPtr->npoints; ++n) {
        xlist[n] = n * interval;
        if (n % 5 == 0)
            factor = rand() % 1000;
        ilist[n] = (float)((-1 * factor) * cos(xlist[n]) + factor);
    }
    return 0;
}

/*
 * Create the file.
 * We first lay out the essential blocks in the right locations as we
 * know the size of the data section. Then backfill the data as it is
 * provided.
 */

static int
Create(int fd, const int batch, const int once, const char *reopen, uint64_t nspectra, uint32_t npoints)
{
    WdfHeader hdr;
    WdfBlock block;
    uint64_t pos = 0, xlistoffset = 0, ylistoffset = 0, originoffset = 0;
    int n;

    memset(&hdr, 0, sizeof(hdr));

    /* default field values */
    hdr.signature = WDF_BLOCKID_FILE;
    hdr.version = WDF_FILE_VERSION;
    hdr.size = sizeof(WdfHeader);
    hdr.scantype = WdfScanType_Static;
    hdr.units = WdfDataUnits_Counts;
    hdr.type = (nspectra > 1) ? WdfType_Series : WdfType_Single;
    hdr.nspectra = nspectra;
    hdr.npoints = npoints;
    hdr.ylistcount = 1;
    hdr.xlistcount = hdr.npoints;
    hdr.origincount = 1;
    hdr.appversion[0] = 1;
    hdr.time_start = GetTimestamp(0);
    memcpy(hdr.appname, "wdf_create", 10);

    /* write header and spectra section */
    {
        block.id = WDF_BLOCKID_DATA;
        block.uid = 0;
        block.size = sizeof(WdfBlock)
            + (hdr.nspectra * hdr.npoints * sizeof(float));
        snprintf((char *)hdr.user, 32, "luser");
        snprintf((char *)hdr.title, 160, "Descriptive title of file data.");
        Write(fd, 0, &hdr, sizeof(hdr));
        Write(fd, sizeof(hdr), &block, sizeof(WdfBlock));
        pos = sizeof(WdfHeader) + block.size;
    }

    /* write ylist block at the calculated offset */
    {
        block.id = WDF_BLOCKID_YLIST;
        block.uid = 0;
        block.size = sizeof(WdfBlock) + (2 * sizeof(uint32_t)) + (sizeof(float) * hdr.ylistcount);
        ylistoffset = pos;
        Write(fd, pos, &block, sizeof(WdfBlock));
        pos += block.size;
    }

    /* write xlist block */
    {
        block.id = WDF_BLOCKID_XLIST;
        block.uid = 0;
        block.size = sizeof(WdfBlock) + (2 * sizeof(uint32_t) + (sizeof(float) * hdr.xlistcount));
        xlistoffset = pos;
        Write(fd, pos, &block, sizeof(WdfBlock));
        pos += block.size;
    }

    /* write data origin block marker */
    if (hdr.nspectra > 1)
    {
        int num_origins = hdr.origincount;
        uint32_t types[1] = {WdfDataType_Time};
        uint32_t units[1] = {WdfDataUnits_FileTime};
        size_t origin_size = (size_t)((2*sizeof(uint32_t)) + 16
                                      + (sizeof(double)*hdr.nspectra));
        uint64_t origin_start = pos + sizeof(WdfBlock) + sizeof(uint32_t);
        block.id = WDF_BLOCKID_ORIGIN;
        block.uid = 0;
        block.size = sizeof(WdfBlock) + sizeof(uint32_t) + (num_origins * origin_size);
        originoffset = pos;
        Write(fd, pos, &block, sizeof(WdfBlock));
        /* write the count */
        Write(fd, pos+sizeof(WdfBlock), &num_origins, sizeof(uint32_t));
        /* for each origin, write the type, units and label (empty label)*/
        for (n = 0; n < num_origins; ++n) {
            uint32_t x[3]; x[0] = types[n], x[1] = units[n]; x[2] = 0x656d6954;
            Write(fd, origin_start + (n * origin_size), x, sizeof(uint32_t)*3);
        }
        pos += block.size;
    }

    /* Write a text block - just contains utf-8 string data. */
    {
        char buffer[80];
        WdfBlock *blockPtr = (WdfBlock *)buffer;
        memset(buffer, 0, sizeof(buffer));
        blockPtr->id = WDF_BLOCKID_COMMENT;
        blockPtr->uid = 0;
        blockPtr->size = sizeof(buffer);
        sprintf(buffer+sizeof(WdfBlock), "This is a sample file created using wdf_create.");
        Write(fd, pos, buffer, sizeof(buffer));
        pos += blockPtr->size;
    }

    /* write out each spectrum */
    {
        float *ylist, *xlist, *ilist;
        size_t count;
        uint64_t *times, offset, ncollected = 0;
        int fd2 = fd;
        int cn = 0;
        ylist = (float *)malloc(sizeof(float) * hdr.ylistcount * batch);
        xlist = (float *)malloc(sizeof(float) * hdr.xlistcount * batch);
        ilist = (float *)malloc(sizeof(float) * hdr.npoints * batch);
        times = (uint64_t *)malloc(sizeof(uint64_t) * batch);
        n = 0;
        if (once) {
            for (cn = 0; cn < batch && (n+cn) < hdr.nspectra; ++cn) {
                GetSpectrum(&hdr, ylist+(hdr.ylistcount*cn), xlist+(hdr.xlistcount*cn), ilist+(hdr.npoints*cn));
            }
        }
        while (n < hdr.nspectra) {
            if (reopen != NULL)
                fd2 = _open(reopen, _O_RDWR | _O_BINARY, _S_IREAD | _S_IWRITE);
            for (cn = 0; cn < batch && (n+cn) < hdr.nspectra; ++cn) {
                if (!once) {
                    GetSpectrum(&hdr, ylist+(hdr.ylistcount*cn), xlist+(hdr.xlistcount*cn), ilist+(hdr.npoints*cn));
                }
                times[cn] = GetTimestamp(n+cn);
            }
            if (n == 0) {
                uint32_t type = WdfDataType_Spectral;
                uint32_t units = WdfDataUnits_Pixels;
                /* do ylist */
                _lseeki64(fd, ylistoffset + sizeof(WdfBlock), SEEK_SET);
                _write(fd, &type, sizeof(type));
                _write(fd, &units, sizeof(units));
                _write(fd, ylist, sizeof(float) * hdr.ylistcount);
                /* do xlist */
                units = WdfDataUnits_RamanShift;
                _lseeki64(fd, xlistoffset + sizeof(WdfBlock), SEEK_SET);
                _write(fd, &type, sizeof(type));
                _write(fd, &units, sizeof(units));
                _write(fd, xlist, sizeof(float) * hdr.xlistcount);
            }
            
            /* write the new collected data (batch mode) */

            /* update ncollected */
            ncollected += cn;
            Write(fd2, offsetof(WdfHeader, ncollected), &ncollected, sizeof(ncollected));

            /* write the spectrum ilist */
            offset = sizeof(WdfHeader) + sizeof(WdfBlock)
                + ((uint64_t)n * hdr.npoints * sizeof(float));
            count = sizeof(float) * hdr.npoints * cn;
            Write(fd2, offset, ilist, count);

            /* add the time data origin */
            {
                uint64_t t = 0;
                size_t originsize = (size_t)((2 * sizeof(uint32_t)) + 16
                                             + (hdr.nspectra * sizeof(double)));
                offset = originoffset /* start of block */
                    + sizeof(WdfBlock)    /* block header */
                    + sizeof(uint32_t)    /* number of origins */
                    + (0 * originsize)    /* which origin list (time == 0) */
                    + (2 * sizeof(uint32_t) + 16) /* the originlist type,units and label */
                    + (sizeof(double) * n); /* this data item */
                Write(fd2, offset, times, sizeof(uint64_t) * cn);
            }
            if (reopen != NULL)
                _close(fd2);
            /* update the spectrum count */
            n += cn;
        }
        Write(fd, offsetof(WdfHeader, time_end), &times[cn>0?cn-1:0], sizeof(uint64_t));
        free(ylist), free(xlist), free(ilist), free(times);
    }

    return n;
}

#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winioctl.h>

int
main(int argc, char *argv[])
{
    LARGE_INTEGER freq, t[3];
    uint64_t nspectra = 1;
    uint32_t npoints = 1024;
    const char *reopen = NULL;
    int fd, n, sparse = 0, batch = 1, once = 0;

    if (argc < 2) {
        fprintf(stderr, "usage: wdfcreate filename ?options?\n");
        fprintf(stderr, "  -nspectra N\n  -npoints N\n  -sparse\n");
        exit(1);
    }

    /* parse data size from command-line arguments */
    for (n = 2; n < argc; ++n) {
        if (strcmp("-npoints", argv[n]) == 0) {
            ++n;
            npoints = strtoul(argv[n], NULL, 0);
        } else if (strcmp("-nspectra", argv[n]) == 0) {
            ++n;
            nspectra = _strtoui64(argv[n], NULL, 0);
        } else if (strcmp("-sparse", argv[n]) == 0) {
            sparse = 1;
        } else if (strcmp("-once", argv[n]) == 0) {
            once = 1;
        } else if (strcmp("-reopen", argv[n]) == 0) {
            reopen = argv[1];
        } else if (strcmp("-batch", argv[n]) == 0) {
            ++n;
            batch = strtoul(argv[n], NULL, 0);
        } else {
            fprintf(stderr, "unrecognized option \"%s\"\n", argv[n]);
            exit(1);
        }
    }

    srand((unsigned int)time(NULL));

    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t[0]);
    QueryPerformanceCounter(&t[1]);

    fd = _open(argv[1], _O_RDWR | _O_CREAT | _O_TRUNC | _O_BINARY, _S_IREAD | _S_IWRITE);
    if (fd != -1) {
        if (sparse) {
            DWORD cb = 0;
            DeviceIoControl((HANDLE)_get_osfhandle(fd), FSCTL_SET_SPARSE, NULL, 0, NULL, 0, &cb, NULL);
        }
        Create(fd, batch, once, reopen, nspectra, npoints);
        _close(fd);
    } else {
        perror("open");
    }

    QueryPerformanceCounter(&t[2]);

    {
        uint64_t ohd;
        double df, dt, ms, dr;
        struct _stati64 sb = {0};
        ohd = t[1].QuadPart - t[0].QuadPart;
        dt = (double)(t[2].QuadPart - t[1].QuadPart - ohd);
        df = (double)freq.QuadPart;
        ms = dt/(df / 1000.0);
        _stati64(argv[1], &sb);
        dr = (sb.st_size / 1048576.0) / (ms / 1000.0);
        printf("%.3f ms %.3f datasets/ms data rate %.3f MB/s\n", ms, nspectra/ms, dr);
    }

    return 0;
}
