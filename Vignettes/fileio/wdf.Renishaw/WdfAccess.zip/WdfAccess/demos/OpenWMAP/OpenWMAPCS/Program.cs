﻿/* 
 * OpenWMAP - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * This demo shows how to open a .wdf file and extract the WMAP data using C#
 * 
 * Ensure that WiREDataFormats.dll has been referenced. Create a variable of
 * type WdfFile with parameters for file name and access rights. In this demo
 * the file name is taken from the first command line argument.
 * 
 * Using the WdfFile object it is possible to open relevent WMAP data
 */

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace OpenWMAP
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string fileName = args[0];
                using (WdfFile file = new WdfFile(fileName, WdfFileAccess.ReadOnly))
                {
                    WdfSpectrumCollection spectrum = file.SpectrumCollection;

                    IWiREMapVolume map = spectrum.MapVolume;
                    WiREMapVolumeHelper mapHelp = new WiREMapVolumeHelper(map);
                    WiREMapVolumeFlags flag = map.Flags;
                    WiREVector3<float> stepSize = map.GetStepSize();
                    WiREVector3<int> pointCount = map.GetPointCount();
                    double x, y, z;
                    mapHelp.GetVoxelPositionForSpectrum(0, out x, out y, out z);
                    int lfcount = map.LineFocusCount;

                    Console.WriteLine(flag);
                    Console.WriteLine(x + " " + y + " " + z);
                    Console.WriteLine(stepSize.X + " " + stepSize.Y + " " + stepSize.Z);
                    Console.WriteLine(pointCount.X + " " + pointCount.Y + " " + pointCount.Z);
                    Console.WriteLine(lfcount);
                }
            }
        }
    }
}
