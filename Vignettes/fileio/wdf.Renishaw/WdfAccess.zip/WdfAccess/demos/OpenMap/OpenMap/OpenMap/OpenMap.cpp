 /* OpenMap - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * OpenMap.cpp : Defines the entry point for the console application.
 */

#include "stdafx.h"
#include <wdfapi.h>
#include <string.h>
#include <Windows.h>

#pragma comment(lib, "wdf")

int _tmain()
{
    WDF_HANDLE handle;
    //Open the file;
    WDF_STATUS status = Wdf_Open(L"C:\\data\\Anadin2.wdf", L"r", &handle);
    if (WDF_SUCCESS(status))
    {
        WDF_STREAM stream;
        WdfBlock block;
        //Open the file 
        status = Wdf_OpenSection(handle, WDF_BLOCKID_MAP, WDF_BLOCKID_ANY, &stream, &block);
        if (WDF_SUCCESS(status))
        {
            uint32_t magic;
            uint32_t psetSize;
            //Read of the magic number and stream size
            status = Wdf_Read(stream, &magic, sizeof(magic), NULL);
            if (magic == WDF_STREAM_IS_PSET)
            {
                if (WDF_SUCCESS(status))
                    status = Wdf_Read(stream, &psetSize, sizeof(psetSize), NULL);
                WDF_PSET pset;
                //Open the property set
                if (WDF_SUCCESS(status))
                    status = Wdf_OpenPropertySet(stream, static_cast<uint64_t>(psetSize), &pset);
                if (WDF_SUCCESS(status))
                {
                    WDF_PROPERTY prop;
                    status = Wdf_GetPropertyItem(pset, L"Type", &prop);
                    if (WDF_SUCCESS(status))
                    {
                        //create char buffer of length equal to the string
                        char* Type = new char[prop->length];
                        //copy the string
                        strncpy(Type, prop->val.strVal, prop->length);
                        delete [] Type;
                    }
                    if (WDF_SUCCESS(status))
                        status = Wdf_GetPropertyItem(pset, L"Time", &prop);
                    if (WDF_SUCCESS(status))
                    {
                        //To get the time one must utilize a ULARGE_INTEGER struct.
                        ULARGE_INTEGER uli;
                        uli.QuadPart = prop->val.timeVal;
                        FILETIME ft;
                        ft.dwHighDateTime = uli.HighPart;
                        ft.dwLowDateTime = uli.LowPart;
                    }
                    if (WDF_SUCCESS(status))
                        status = Wdf_GetPropertyItem(pset, L"Version", &prop);
                    if (WDF_SUCCESS(status))
                    {
                        //create char buffer of length equal to the string
                        char* Type = new char[prop->length];
                        //copy the string
                        strncpy(Type, prop->val.strVal, prop->length);
                        delete [] Type;
                    }
                    if (WDF_SUCCESS(status))
                        status = Wdf_GetPropertyItem(pset, L"MapType", &prop);
                    if (WDF_SUCCESS(status))
                    {
                        uint32_t maptype=0;
                        maptype = prop->val.ulVal;
                    }
                    if (WDF_SUCCESS(status))
                        status = Wdf_GetPropertyItem(pset, L"DataList0", &prop);
                    if (WDF_SUCCESS(status))
                    {
                        WdfDataType datatype;
                        datatype = static_cast<WdfDataType>(prop->val.ulVal);
                    }
                    if (WDF_SUCCESS(status))
                        status = Wdf_GetPropertyItem(pset, L"DataList1", &prop);
                    if (WDF_SUCCESS(status))
                    {
                        WdfDataType datatype;
                        datatype = static_cast<WdfDataType>(prop->val.ulVal);
                    }
                    Wdf_ClosePropertySet(pset);
                }
                uint64_t npoints=0;
                //read off the number of points
                if (WDF_SUCCESS(status))
                    status = Wdf_Read(stream, &npoints, sizeof(npoints), NULL);
                float *dataptr = new float[npoints];
                //read off the data
                if (WDF_SUCCESS(status) && (dataptr != NULL))
                    status = Wdf_Read(stream, dataptr, sizeof(float)*static_cast<uint32_t>(npoints), NULL);
                delete [] dataptr;
            }
            Wdf_CloseStream(stream);
        }
        Wdf_Close(handle);
    }
	return 0;
}

