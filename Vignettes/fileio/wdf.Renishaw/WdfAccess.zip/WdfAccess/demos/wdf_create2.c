/* wdf_create - Copyright (c) 2011 Renishaw plc. All rights reserved.
 *
 * Sample program to show how to create a wdf file.
 * Note: as there is nothing Windows specific in this file this can
 *       also be used to check that the wdf.h header is platform
 *       independent. The program should compile on any platform.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <assert.h>
#include <wdf.h>
#include <wdfapi.h>
#include <tchar.h>

/*
 * Get a FILETIME compatible value based on the start time
 * offset by 1 second per spectrum
 */

static uint64_t
GetTimestamp(uint64_t n)
{
    static uint64_t base = 0;
    if (base == 0) {
        base = (uint64_t)time(NULL);
    }
    /* converts time_t to FILETIME */
#ifdef _MSC_VER
    return ((base + n) * 10000000) + 116444736000000000I64;
#else
    return ((base + n) * 10000000) + 116444736000000000ULL;
#endif
}

/*
 * Generate spectral data (a noisy sine wave)
 * The size of the various spectra are passed via the WdfHeader structure
 * and this must match the buffer sizes passed here. Therefore ensure
 * that ylistcount and xlistcount and npoints are correct and used.
 */

static int
GetSpectrum(WdfHeader *hdrPtr, float *ylist, float *xlist, float *ilist)
{
    uint32_t n, y;
    const int npeaks = 3;
    float interval = (float)((npeaks * 2 * 3.1415) / hdrPtr->xlistcount);
    for (n = 0; n < hdrPtr->ylistcount; ++n) {
        ylist[n] = 200.0f + n;
    }
    for (n = 0; n < hdrPtr->xlistcount; ++n) {
        xlist[n] = n * interval;
        for (y = 0; y < hdrPtr->ylistcount; ++y) {
            int factor = rand() % 1000;
            ilist[(y*hdrPtr->xlistcount)+n] = (float)((-1 * factor) * cos(xlist[n]) + factor);
        }
    }
    return 0;
}

/*
 * Create a custom section (section id uses lowercase ascii values)
 * and fill with a property set of various values.
 */

static WDF_STATUS
AppendCustomSection(WDF_HANDLE handle, const uint32_t blockid)
{
    WDF_PSET pset = NULL;
    WDF_STREAM stream = NULL, ostream = NULL;
    uint64_t pos = 0;
    int len = 1024, wrote = 0;
    char buffer[1024];
    
    /* create the property set and serialize to stream */
    WDF_STATUS status = Wdf_CreatePropertySet(&pset);
    if (WDF_SUCCESS(status)) {
        status = Wdf_SetPropertyItemInt(pset, _T("count"), 1);
        status = Wdf_SetPropertyItemInt(pset, _T("ErrorCode"), 100);
        if (WDF_SUCCESS(status))
            status = Wdf_SetPropertyItemFloat(pset, _T("start"), 1104.2f);
        if (WDF_SUCCESS(status))
            status = Wdf_SetPropertyItemFloat(pset, _T("end"), 2104.3f);
        if (WDF_SUCCESS(status))
            status = Wdf_SetPropertyItemString(pset, _T("username"), _T("myself"));
        if (WDF_SUCCESS(status))
            status = Wdf_CreateStream(0, &stream);
        if (WDF_SUCCESS(status))
            status = Wdf_SavePropertySet(pset, stream);
        Wdf_ClosePropertySet(pset);
    }
    /* copy the stream to a wdf section */
    if (WDF_SUCCESS(status) && stream != NULL) {
        uint32_t magic = WDF_STREAM_IS_PSET, pset_size = 0;
        status = Wdf_Tell(stream, &pos);
        pset_size = (uint32_t)pos;
        if (WDF_SUCCESS(status))
            status = Wdf_Seek(stream, 0, SEEK_SET);
        if (WDF_SUCCESS(status))
            status = Wdf_CreateSection(handle, blockid, -1, pos+8, &ostream);
        if (WDF_SUCCESS(status))
            status = Wdf_Write(ostream, &magic, sizeof(magic), &wrote);
        if (WDF_SUCCESS(status))
            status = Wdf_Write(ostream, &pset_size, sizeof(pset_size), &wrote);
        while (WDF_SUCCESS(status) && len == 1024) {
            status = Wdf_Read(stream, buffer, sizeof(buffer), &len);
            if (WDF_SUCCESS(status))
                status = Wdf_Write(ostream, buffer, len, &wrote);
        }
        Wdf_CloseStream(stream);
        Wdf_CloseStream(ostream);
    }
    return status;
}

static WDF_STATUS
WritePSetToSection(WDF_PSET pset, WDF_STREAM ostream)
{
    WDF_STREAM stream;
    uint64_t pos;
    int len = 1024, wrote = 0;
    char buffer[1024];

    WDF_STATUS status = Wdf_CreateStream(0, &stream);
    if (WDF_SUCCESS(status)) {
        uint32_t magic = WDF_STREAM_IS_PSET, pset_size;
        status = Wdf_SavePropertySet(pset, stream);
        if (WDF_SUCCESS(status))
            status = Wdf_Tell(stream, &pos);
        
        /* rewind the both streams */
        if (WDF_SUCCESS(status))
            status = Wdf_Seek(stream, 0, SEEK_SET);
        if (WDF_SUCCESS(status))
            status = Wdf_Seek(ostream, 0, SEEK_SET);

        /* rewrite the stream magic and size (in this case we dont deal with
         changing the size of the block) */
        pset_size = (uint32_t)pos;
        if (WDF_SUCCESS(status))
            status = Wdf_Write(ostream, &magic, sizeof(magic), &wrote);
        if (WDF_SUCCESS(status))
            status = Wdf_Write(ostream, &pset_size, sizeof(pset_size), &wrote);

        /* copy the data from the new stream to the output stream */
        while (WDF_SUCCESS(status) && len == 1024) {
            status = Wdf_Read(stream, buffer, sizeof(buffer), &len);
            if (WDF_SUCCESS(status))
                status = Wdf_Write(ostream, buffer, len, &wrote);
        }
        Wdf_CloseStream(stream);
    }
    return status;
}

static WDF_STATUS
ModifyCustomSection(WDF_HANDLE handle, const uint32_t blockid)
{
    WDF_PSET pset = NULL;
    WDF_STREAM stream = NULL, ostream = NULL;
    WdfBlock block;
    uint64_t pos = 0;
    
    WDF_STATUS status = Wdf_OpenSection(handle, blockid, -1, &stream, &block);
    if (WDF_SUCCESS(status)) {
        uint32_t pset_size = 0;
        int cb = 0;
        status = Wdf_Read(stream, &pset_size, sizeof(uint32_t), &cb);
        if (WDF_SUCCESS(status) && pset_size == WDF_STREAM_IS_PSET)
            status = Wdf_Read(stream, &pset_size, sizeof(uint32_t), &cb);
        if (WDF_SUCCESS(status))
            status = Wdf_OpenPropertySet(stream, pset_size, &pset);
        if (WDF_SUCCESS(status)) {
            status = Wdf_SetPropertyItemFloat(pset, _T("start"), 1900.0f);
            if (WDF_SUCCESS(status))
                status = Wdf_SetPropertyItemInt(pset, _T("ErrorCode"), 0x343332);
            if (WDF_SUCCESS(status))
                status = WritePSetToSection(pset, stream);
            Wdf_ClosePropertySet(pset);
        }
        Wdf_CloseStream(stream);
    }
    return status;
}

static WDF_STATUS
Fill(WDF_HANDLE handle, uint64_t nspectra)
{
    WdfHeader hdr;
    WDF_STATUS status = WDF_OK;

    status = Wdf_GetHeader(handle, &hdr);

    /* write out each spectrum */
    if (WDF_SUCCESS(status))
    {
        float *ylist, *xlist, *ilist;
        uint64_t n, t, width = (uint64_t)sqrt((double)(int64_t)hdr.nspectra);
        
        ylist = (float *)malloc(sizeof(float) * hdr.ylistcount);
        xlist = (float *)malloc(sizeof(float) * hdr.xlistcount);
        ilist = (float *)malloc(sizeof(float) * hdr.npoints);
        for (n = 0; n < hdr.nspectra; ++n) {
            GetSpectrum(&hdr, ylist, xlist, ilist);
            t = GetTimestamp(n);
            if (n == 0) {
                /* do xlist and ylist just once */
                status = Wdf_SetYList(handle, 0, hdr.ylistcount - 1, ylist);
                assert(WDF_SUCCESS(status));
                status = Wdf_SetXList(handle, 0, hdr.xlistcount - 1, xlist);
                assert(WDF_SUCCESS(status));
            }
            status = Wdf_SetSpectrumData(handle, n, 0, hdr.npoints - 1, ilist);
            assert(WDF_SUCCESS(status));
            if (hdr.origincount > 1) {
                status = Wdf_SetOriginData(handle, WdfDataType_Time, (int)n, (int)n, (double *)&t);
                assert(WDF_SUCCESS(status));
            }
            if (hdr.origincount == 3) {
                double x = (double)(int64_t)(n % width);
                double y = (double)(int64_t)(n / width);
                status = Wdf_SetOriginData(handle, WdfDataType_Spatial_X, (int)n, (int)n, (double *)&x);
                assert(WDF_SUCCESS(status));
                status = Wdf_SetOriginData(handle, WdfDataType_Spatial_Y, (int)n, (int)n, (double *)&y);
                assert(WDF_SUCCESS(status));
            }
        }
        free(ylist), free(xlist), free(ilist);
        /* update the ncollected field */
        Wdf_SetField(handle, 72 /*offsetof(WdfHeader, ncollected)*/, &n, sizeof(n));
    }

    return status;
}

int
_tmain(int argc, TCHAR *argv[])
{
    int n;
    uint64_t nspectra = 1;
    uint32_t xlistcount = 576, ylistcount = 1;
    int fill = 1;
    WDF_HANDLE handle = NULL;
    WDF_STATUS status = WDF_OK;
    
    if (argc < 2) {
        _ftprintf(stderr, _T("usage: wdfcreate filename ?options?\n"));
        _ftprintf(stderr, _T("  -nspectra N\n  -xlistcount N\n  -ylistcount N\n  -no-fill\n"));
        exit(1);
    }

    srand((unsigned int)time(NULL));

    /* parse data size from command-line arguments */
    for (n = 2; n < argc; ++n) {
        if (_tcsncmp(_T("-nspectra"), argv[n], 3) == 0
            || _tcsncmp(_T("-spectra"), argv[n], 3) == 0) {
            ++n;
            nspectra = (uint64_t)_tcstoul(argv[n], NULL, 0);
        } else if (_tcsncmp(_T("-ylistcount"), argv[n], 3) == 0) {
            ++n;
            ylistcount = _tcstoul(argv[n], NULL, 0);
        } else if (_tcsncmp(_T("-xlistcount"), argv[n], 3) == 0
                   || _tcsncmp(_T("-npoints"), argv[n], 3) == 0) {
            ++n;
            xlistcount = _tcstoul(argv[n], NULL, 0);
        } else if (_tcsncmp(_T("-no-fill"), argv[n], 4) == 0) {
            fill = 0;
        } else {
            _ftprintf(stderr, _T("unrecognized option \"%s\"\n"), argv[n]);
            exit(1);
        }
    }

    /*
     * Create the basic file structure for the sizes provided
     */

    status = Wdf_Create(argv[1], nspectra, xlistcount, ylistcount, &handle);
    if (WDF_SUCCESS(status))
    {
        /*
         * Append a TEXT comment section.
         * This section contains only UTF-8 encoded text.
         */

        WDF_STREAM stream = NULL;
        status = Wdf_CreateSection(handle, WDF_BLOCKID_COMMENT, 0, 80, &stream);
        if (WDF_SUCCESS(status)) {
            const char *s = "This is an example description for a generated WDF file.";
            int cb = 0;
            status = Wdf_Write(stream, s, strlen(s), &cb);
            Wdf_CloseStream(stream), stream = NULL;
        }

        /*
         * For a multi-spectrum file, add a data origin section
         */

        if (nspectra > 1) {
            WdfOriginType origins[3] = {
                /* type                  units        alternate label*/
                {WdfDataType_Time,      0,                   1, "Time" },
                {WdfDataType_Spatial_X, WdfDataUnits_Micron, 0, "X" },
                {WdfDataType_Spatial_Y, WdfDataUnits_Micron, 0, "Y"},
            };
            status = Wdf_CreateOriginData(handle, 3, origins);
        }

        /*
         * Fill the file with spectral data.
         */

        if (fill)
            status = Fill(handle, nspectra);

        /*
         * Append some custom data
         */

        if (WDF_SUCCESS(status))
            status = AppendCustomSection(handle, WDF_BLOCKID_WIREDATA);
        if (WDF_SUCCESS(status))
            status = ModifyCustomSection(handle, WDF_BLOCKID_WIREDATA);

        if (!WDF_SUCCESS(status))
            _tprintf(_T("error: something went wrong.\n"));

        Wdf_Close(handle);
    }
    return 0;
}
