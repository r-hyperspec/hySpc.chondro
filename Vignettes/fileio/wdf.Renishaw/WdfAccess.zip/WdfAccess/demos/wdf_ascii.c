/* wdf_ascii.c - Copyright (c) 2013 Renishaw plc. All rights reserved.
 *
 * Output a chosen spectrum as ASCII text (2 columns: xlist ilist)
 *
 */

#ifndef _WIN32
   /* unix / linux support */
#  define _LARGEFILE64_SOURCE
#  include <unistd.h>
#  define _lseeki64 lseek64
#  define _open open
#  define _close close
#  define _read read
#  define _strtoui64 strtoull
#  define _O_RDONLY O_RDONLY
#  define _O_BINARY 0
#else
#  define _CRT_SECURE_NO_WARNINGS
#  include <io.h>
#endif

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <wdf.h>

/*
 * open a wdf file and check that it really is a wdf file.
 *
 * @param[in] filename - path of the file to open
 * @param[out] wdfPtr - pointer to a WdfHeader structure to hold the file header.
 * @return returns the C library file handle on success or -1 on failure
 */
static int
OpenWdf(const char *filename, WdfHeader *wdfPtr)
{
    int fd = _open(filename, _O_RDONLY | _O_BINARY, _S_IREAD | _S_IWRITE);
    if (fd != -1) {
        int cb;
        cb = _read(fd, wdfPtr, sizeof(WdfHeader));
        if (wdfPtr->signature != WDF_BLOCKID_FILE) {
            fprintf(stderr, "error: invalid file format\n");
            exit(1);
        }
    }
    return fd;
}

/*
 * scan the blocks in a wdf file looking for a matching block id.
 *
 * @param[in] fd - C library file descriptor for the file
 * @param[in] id - block id (eg: WDF_BLOCKID_DATA)
 * @param[in] uid - block unique id value (may be WDF_BLOCKID_ANY).
 * @return on success returns the file offset of the start of the block.
 *         on failure, returns -1.
 */
static uint64_t
FindSection(int fd, uint32_t id, uint32_t uid)
{
    WdfBlock block = {0};
    uint64_t offset = 0, size = 0;

    size = _lseeki64(fd, 0, SEEK_END);
    while (offset < size) {
        int cb = 0;
        if (_lseeki64(fd, offset, SEEK_SET) < 0) break;
        if ((cb = _read(fd, &block, sizeof(block))) != sizeof(block)) break;
        if (id == block.id) {
            if (uid == WDF_BLOCKID_ANY || uid == block.uid) {
                return offset;
            }
        }
        offset += block.size;
    }
    return (uint64_t)-1;
}

/*
 * read a spectrum from a given file offset.
 *
 * @param[in] fd - the C library file handle for this file
 * @param[in] base - the file offset for the start of the DATA block
 * @param[in] length - number of elements per spectrum (ie: header.npoints)
 * @param[in] spectrum - the 0-based spectrum number to read
 * @param[out] ilist - pointer to the array to read into.
 * @return on success returns the number of bytes read. Returns -1 on failure.
 */
static int
ReadSpectrum(int fd, uint64_t base, uint32_t length, uint64_t spectrum, float *ilist)
{
    int r = -1;
    if (_lseeki64(fd, base + sizeof(WdfBlock) + (sizeof(float) * length * spectrum), SEEK_SET) != -1)
        r = _read(fd, ilist, sizeof(float)*length);
    return r;
}

/*
 * read the spectral xlist data
 *
 * @param[in] fd - the C library file handle for this file
 * @param[in] base - the file offset for the start of the DATA block
 * @param[in] length - number of elements per spectrum (ie: header.npoints)
 * @param[out] xlist - pointer to the array to read into.
 * @return on success returns the number of bytes read. Returns -1 on failure.
 */
static int
ReadXlist(int fd, uint64_t base, uint32_t length, float *xlist)
{
    int r = -1;
    if (_lseeki64(fd, base + sizeof(WdfBlock) + (2 * sizeof(uint32_t)), SEEK_SET) != -1)
        r = _read(fd, xlist, sizeof(float) * length);
    return r;
}

static void
usage()
{
    printf("usage: wdf_ascii filename ?spectrum?\n");
}

int
main(int argc, char *argv[])
{
    WdfHeader hdr = {0};
    uint64_t spectrum = 0;
    uint32_t n;
    int fd;

    /* check the arguments for the optional spectrum number */
    if (argc < 2 || argc > 3) {
        usage();
        return 1;
    }
    if (argc == 3)
        spectrum = _strtoui64(argv[2], NULL, 0);

    /* open the file and read the header information */
    fd = OpenWdf(argv[1], &hdr);
    if (fd != -1) {
        float *xlist = NULL, *ilist = NULL;
        uint64_t section_offset;

        if (spectrum > hdr.nspectra) {
            fprintf(stderr, "invalid spectrum: must be between 0 and %ld\n", hdr.nspectra);
            _close(fd);
            return 1;
        }

        xlist = (float *)malloc(sizeof(float) * hdr.npoints);
        ilist = (float *)malloc(sizeof(float) * hdr.npoints);

        /* find the xlist block and read the xlist data */
        section_offset = FindSection(fd, WDF_BLOCKID_XLIST, 0);
        if (section_offset != -1)
            ReadXlist(fd, section_offset, hdr.npoints, xlist);
        
        /* find the data block and read the specified spectrum ilist data */
        section_offset = FindSection(fd, WDF_BLOCKID_DATA, 0);
        if (section_offset != -1)
            ReadSpectrum(fd, section_offset, hdr.npoints, spectrum, ilist);

        /* emit the spectrum using the ASCII output format to stdout */
        for (n = 0; n < hdr.npoints; ++n) {
            printf("%.3f\t%.3f\n", xlist[n], ilist[n]);
        }

        free(xlist);
        free(ilist);
        _close(fd);
    }
    return 0;
}
