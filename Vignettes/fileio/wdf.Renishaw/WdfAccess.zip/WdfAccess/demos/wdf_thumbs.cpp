// Copyright (c) 2011 Renishaw plc. All rights reserved.
//
// Create thumbnails - demonstrates reading data from WDF files.
//
// Given a wdf file, this program generates a thumbnail PNG image file
// by drawing a line spectrum using the first dataset i-list data and
// writing the result to a new specificed image file.
// The images are 64x64 pixels
// You may emit other types by providing a suitable mime type as the 
// third argument (eg: image/jpeg)

#define UNICODE
#define _UNICODE
#define STRICT
//#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <GdiPlus.h>
#include <wdfapi.h>

#pragma comment(lib, "gdiplus")
#pragma comment(lib, "gdi32")
#pragma comment(lib, "user32")
#pragma comment(lib, "wdf")

static HRESULT
GetEncoderClsid(LPCWSTR format, LPCLSID pclsid)
{
    HRESULT hr = E_FAIL;
    UINT num = 0;          // number of image encoders
    UINT size = 0;         // size of the image encoder array in bytes
    Gdiplus::GetImageEncodersSize(&num, &size);
    if (size != 0)
    {
        Gdiplus::ImageCodecInfo *pImageCodecInfo = (Gdiplus::ImageCodecInfo*)new BYTE[size];
        if (pImageCodecInfo)
        {
            GetImageEncoders(num, size, pImageCodecInfo);
            for (UINT n = 0; n < num; ++n)
            {
                if (wcscmp(pImageCodecInfo[n].MimeType, format) == 0)
                {
                    *pclsid = pImageCodecInfo[n].Clsid;
                    hr = S_OK;
                    break;
                }
            }
            delete [] pImageCodecInfo;
        }
    }
    return hr;
}

static HBITMAP
Create32bppDIB(HDC hdc, int cx, int cy)
{
    BITMAPINFO bi = {0};
    bi.bmiHeader.biWidth = cx;
    bi.bmiHeader.biHeight = cy;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biSizeImage = 0;
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biClrUsed = 0;
    bi.bmiHeader.biClrImportant = 0;
    void *pBits = 0;
    return CreateDIBSection(hdc, &bi, DIB_RGB_COLORS, &pBits, NULL, 0);
}

static int
CreateThumbnail(int size, float *data, size_t length, LPCTSTR filename, LPCTSTR mimetype)
{
    using namespace Gdiplus;
    
    HBITMAP hbmp = Create32bppDIB(GetDC(NULL), size, size);
    Image *image = new Bitmap(hbmp, (HPALETTE)GetStockObject(DEFAULT_PALETTE));
    Graphics g(image);
    SolidBrush brush(Color::White);
    Rect rc(0, 0, size-1, size-1);

    g.Clear(Color::White);
    g.SetSmoothingMode(SmoothingModeAntiAlias);
    g.DrawRectangle(&Pen(Color::Black, 1), rc);
    
    float vmax = 1e-37f, vmin = 1e38f;
    size_t n;
    for (n = 0; n < length; ++n) {
        if (data[n] < vmin) vmin = data[n];
        if (data[n] > vmax) vmax = data[n];
    }
    if (vmax - vmin != 0)
    {
        Point *points = new Point[length];
        double Fx = static_cast<double>(rc.Width) / static_cast<double>(length);
        double Fy = static_cast<double>(rc.Height) / (vmax - vmin);
        int count = 0, last_x = -1;
        for (n = 0; n < length; ++n) {
            int x = rc.X + (rc.Width - static_cast<int>(n * Fx));
            if (x != last_x)
            {
                last_x = points[count].X = x;
                points[count].Y = (rc.Y + rc.Height) - static_cast<int>((data[n] - vmin) * Fy);
                ++count;
            }
        }
        g.DrawCurve(&Pen(Color::Red, 1.0f), points, count, 0);
        delete [] points;
    }
    g.Flush(FlushIntentionSync);
    
    if (image)
    {
        CLSID encoder;
        GetEncoderClsid(mimetype, &encoder);
        
        Gdiplus::EncoderParameters params;
        LONG quality = 90;
        params.Count = 1;
        params.Parameter[0].Guid = Gdiplus::EncoderQuality;
        params.Parameter[0].Type = Gdiplus::EncoderParameterValueTypeLong;
        params.Parameter[0].NumberOfValues = 1;
        params.Parameter[0].Value = &quality;
        
        PropertyItem item;
        item.id = PropertyTagSoftwareUsed;
        item.type = PropertyTagTypeASCII;
        item.value = (void *)"WdfThumb";
        item.length = 8;
        image->SetPropertyItem(&item);
        
        Status status = image->Save(filename, &encoder, &params);
        delete image;
    }
    DeleteObject(hbmp);
    return 0;
}

int
_tmain(int argc, TCHAR *argv[])
{
    if (argc < 3 || argc > 4) {
        _tprintf(_T("usage: wdf_thumb wdffile thumbnailfile ?mimetype?\n"));
        return 1;
    }

    LPCTSTR mimetype = L"image/png";
    if (argc == 4) mimetype = argv[3];
    
    ULONG_PTR gdiptok;
    Gdiplus::GdiplusStartupInput input;
    Gdiplus::GdiplusStartup(&gdiptok, &input, NULL);

    WdfHeader hdr = {0};
    WDF_HANDLE wdf = NULL;

    WDF_STATUS r = Wdf_Open(argv[1], _T("r"), &wdf);
    if (WDF_OK == r)
        r = Wdf_GetHeader(wdf, &hdr);
    if (WDF_OK == r) {
        float *data = new float[hdr.npoints];
        r = Wdf_SpectrumData(wdf, 0, 0, -1, data);
        if (WDF_OK == r)
            r = (WDF_STATUS)CreateThumbnail(64, data, hdr.npoints, argv[2], mimetype);
    }
    if (wdf)
        Wdf_Close(wdf);

    Gdiplus::GdiplusShutdown(gdiptok);
    return r;
}
