#if defined(UNICODE) && !defined(_UNICODE)
#define _UNICODE
#endif
#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include <tchar.h>
#include <wdfapi.h>

#pragma comment(lib, "advapi32")

typedef enum MapMode {Map_IntensityAtPoint, Map_SignalToBaseline, Map_SignalToAxis} MapMode;

typedef struct map_point_t {
    double point;
    size_t index_left;
    size_t index_right;
    float xleft;
    float xright;
    float ileft;
    float iright;
    float intensity;
} map_point_t;

typedef struct map_data {
    MapMode type;    /* the mapping type */
    uint64_t count;  /* number of map points == nspectra */
    map_point_t point[2]; /* point information */
    float *buffer;   /* buffer sufficient to hold the i-list data needed */
    size_t buffer_len;
    float *xlist;    /* pointer to the x-list */
    size_t xlist_len;
    uint64_t dataOffset;   /* offset in dataStream of the first map data value */
    WDF_STREAM dataStream; /* map block data stream */
} map_data;

static WDF_STATUS get_indices_for_point(float *xlist, size_t len, double point, size_t *index);
static WDF_STATUS get_map_point(float *xlist, uint32_t xlen, double point, map_point_t *map_point);
static WDF_STATUS get_map_point_intensities(map_point_t *map_point, float *ilist, uint32_t len, uint32_t offset);


static WDF_STATUS
WriteMapValue(map_data *mapPtr, uint64_t spectrumIndex, float value)
{
    int cb = 0;
    WDF_STATUS status = Wdf_Seek(mapPtr->dataStream, mapPtr->dataOffset + (sizeof(float) * spectrumIndex), SEEK_SET);
    if (WDF_SUCCESS(status))
        status = Wdf_Write(mapPtr->dataStream, &value, sizeof(value), &cb);
    if (!WDF_SUCCESS(status))
        fprintf(stderr, "error writing map point %I64d\n", spectrumIndex);
    return status;
}

/*
 * Calculate the intensity at a point map from a Wdf file
 *
 * This function is called from Wdf_EnumSpectra passing in a pointer to a state structure
 * which contains space for the map datalist and the indices we must read from each
 * spectrum.
 * This function is called once for each spectrum in the file.
 */
static WDF_STATUS
mapPointProc(WDF_HANDLE h, uint64_t spectrumIndex, void *clientData)
{
    struct map_data *mapPtr = clientData;
    WDF_STATUS status = WDF_ERROR_INVALID_ARGUMENT;
    float v[2] = {0, 0};
    map_point_t *pt = &mapPtr->point[0];
    if ((pt->index_right - pt->index_left) == 1)
    {
        float m = (float)0x78000001; /* NaN */
        status = Wdf_SpectrumData(h, spectrumIndex, pt->index_left, pt->index_right, v);
        if (status != WDF_OK)
        {
            _ftprintf(stderr, _T("error @%I64d %08x [%08x %d..%d]\n"),
                      spectrumIndex, status, h, pt->index_left, pt->index_right);
        }
        else
        {
            /* interpolate the two values */
            /* m = (float)(v[0] + (pt->point - pt->xleft) * (v[1] - v[0]) / (pt->xright - pt->xleft)); */
            status = get_map_point_intensities(pt, v, 2, pt->index_left);
            if (WDF_SUCCESS(status))
                m = pt->intensity;
        }
        if (WDF_SUCCESS(status))
            status = WriteMapValue(mapPtr, spectrumIndex, m);
    }
    return status;
}

/*
 * Initialize a map_point structure.
 * This locates the two indices that bound the requested point and the xlist values for those.
 */
static WDF_STATUS
get_map_point(float *xlist, uint32_t xlen, double point, map_point_t *map_point)
{
    size_t ndx[2];
    WDF_STATUS status = get_indices_for_point(xlist, xlen, point, ndx);
    if (WDF_SUCCESS(status))
    {
        map_point->point = point;
        map_point->index_left = ndx[0];
        map_point->index_right = ndx[1];
        if (ndx[0] > xlen || ndx[1] > xlen)
            status = WDF_ERROR_INVALID_ARGUMENT;
        if (WDF_SUCCESS(status))
        {
            map_point->xleft = xlist[map_point->index_left];
            map_point->xright = xlist[map_point->index_right];
        }
    }
    return status;
}
/* 
 * update a map_point item with the intensity values - must already have been initialized
 * the ilist may have been offset by some amount which adjusts the index lookup.
 */
static WDF_STATUS
get_map_point_intensities(map_point_t *map_point, float *ilist, uint32_t len, uint32_t offset)
{
    WDF_STATUS status = WDF_OK;
    if (map_point->index_left < offset || map_point->index_right < offset
        || map_point->index_left > (offset + len) || map_point->index_right > (offset + len))
        status = WDF_ERROR_INVALID_ARGUMENT;
    if (WDF_SUCCESS(status))
    {
        map_point->ileft = ilist[map_point->index_left - offset];
        map_point->iright = ilist[map_point->index_right - offset];
        map_point->intensity = (float)(map_point->ileft + (map_point->point - map_point->xleft)
            * (map_point->iright - map_point->ileft) / (map_point->xright - map_point->xleft));
    }
    return status;
}

/*
 * For both SignalToAxis and SignalToBaseline we calculate the area under the line
 * for the bounded region. For signal to baseline we then subtract the area under the
 * baseline which is calculated by interpolating the trapesium between the two points
 * bounding the region
 */
static WDF_STATUS
mapIntegratedSignal(WDF_HANDLE h, uint64_t spectrumIndex, void *clientData)
{
    struct map_data *mapPtr = clientData;
    WDF_STATUS status = WDF_ERROR_INVALID_ARGUMENT;

    status = Wdf_SpectrumData(h, spectrumIndex, mapPtr->point[0].index_left, mapPtr->point[1].index_right, mapPtr->buffer);
    if (WDF_SUCCESS(status))
    {
        /* integrate the area under the curve using the trapezium rule using
         * each adjacent pair of points:
         *    SUM( (f(a) + f(b))(b - a)/2 )
         */
        double value = 0.0, outer_left = 0.0, inner_right = 0.0;
        size_t index;

        for (index = mapPtr->point[0].index_left; index < (mapPtr->point[1].index_right - 1); ++index) {
            size_t i = index - mapPtr->point[0].index_left;
            value += (mapPtr->buffer[i] + mapPtr->buffer[i+1]) * fabs(mapPtr->xlist[index+1] - mapPtr->xlist[index]);
        }

        /* The requested X points are unlikely to exactly match actual x-list values so we
         * correct by adding and subtracting the excess area from each end of the limit area.
         * We always offset upwards so we remove the area at the lower end and subtract the area
         * from the upper end. The 0.5 here converts the rectangle areas from above into trapeziums
         * in one operation.
         */
        get_map_point_intensities(&mapPtr->point[0], mapPtr->buffer, mapPtr->buffer_len, mapPtr->point[0].index_left);
        get_map_point_intensities(&mapPtr->point[1], mapPtr->buffer, mapPtr->buffer_len, mapPtr->point[0].index_left);

        outer_left = (mapPtr->point[0].intensity + mapPtr->point[0].ileft)
            * fabs(mapPtr->point[0].point - mapPtr->point[0].xleft) * 0.5;
        inner_right = (mapPtr->point[1].intensity + mapPtr->point[1].ileft)
            * fabs(mapPtr->point[1].point - mapPtr->point[1].xleft) * 0.5;
        value = (0.5 * value) + inner_right - outer_left;

        if (mapPtr->type == Map_SignalToBaseline)
        {
            /* Subtract the area under the baseline */
            double base = 0.5 * (mapPtr->point[0].intensity + mapPtr->point[1].intensity)
                * fabs(mapPtr->point[1].point - mapPtr->point[0].point);
            value -= base;
        }
        if (WDF_SUCCESS(status))
            status = WriteMapValue(mapPtr, spectrumIndex, (float)value);
    }
    return status;
}
/*
 * Convert an x-list point into a pair of spectrum indices.
 *
 * When mapping, the point requested may not be a precise match to any actual spectrum index
 * so we always end up with 2 values and interpolate between the upper and lower.
 * The spectral data may also be acquired in either direction so we have to cope with this too.
 *
 * @return WDF_ERROR if the point falls out of range.
 */
static WDF_STATUS
get_indices_for_point(float *xlist, size_t len, double point, size_t *index)
{
    WDF_STATUS status = WDF_ERROR;
    int n = 0, step = 1, end = len;
    if (xlist[0] > xlist[1]) { n = len-1; step = -1; end = -1;}
    for (; n != end; n += step) {
        if (xlist[n] >= point)
        {
            if (step < 0) {
                index[1] = n - step;
                index[0] = n;
            } else {
                index[0] = n - step;
                index[1] = n;
            }
            status = WDF_OK;
            break;
        }
    }
    return status;
}

/*
 * Find the next map uid value to use in this file
 *
 * Enumerates the map blocks and returns the next uid in sequence.
 * The uidPtr parameter should point to a uint32_t that has been initalized to 0.
 */
static WDF_STATUS
get_next_map_enum(WDF_HANDLE h, WdfBlock *blockPtr, void *clientData)
{
    uint32_t *uidPtr = clientData;
    if (blockPtr->id == WDF_BLOCKID_MAP)
    {
        if (blockPtr->uid >= *uidPtr)
            *uidPtr = blockPtr->uid + 1;
    }
    return WDF_OK;
}
static WDF_STATUS
get_next_map_uid(WDF_HANDLE h, uint32_t *uidPtr)
{
    return Wdf_EnumSections(h, get_next_map_enum, (void *)uidPtr);
}

/*
 * Write a new map block into the file using the information in the map state structure
 */
static WDF_STATUS
save_map(WDF_HANDLE handle, map_data *map)
{
    uint64_t pset_size = 0;
    WDF_STREAM stream = NULL;
    WDF_PSET pset = NULL;

    WDF_STATUS status = Wdf_CreatePropertySet(&pset);
    if (WDF_SUCCESS(status))
    {
        WDF_PSET props = NULL;
        TCHAR sz[80];
        status = Wdf_CreatePropertySet(&props);
        if (WDF_SUCCESS(status)) {
            if (map->type == Map_IntensityAtPoint) {
                status = Wdf_SetPropertyItemDouble(props, _T("Point"), map->point[0].point);
            } else {
                status = Wdf_SetPropertyItemDouble(props, _T("FirstLimit"), map->point[0].point);
                if (WDF_SUCCESS(status))
                    status = Wdf_SetPropertyItemDouble(props, _T("SecondLimit"), map->point[1].point);
            }
            if (WDF_SUCCESS(status))
                status = Wdf_SetPropertyItemPset(pset, _T("Properties"), props);
            Wdf_ClosePropertySet(props);
        }
        if (WDF_SUCCESS(status))
            status = Wdf_SetPropertyItemInt(pset, _T("DataList0"), 3);
        if (WDF_SUCCESS(status))
            status = Wdf_SetPropertyItemInt(pset, _T("DataList1"), 4);
        /* the following section is the only bit that has windows specific functions */
        if (WDF_SUCCESS(status)) {
            size_t cch = 80;
            GetUserName(sz, &cch);
            status = Wdf_SetPropertyItemString(pset, _T("Operator"), sz);
        }
        if (WDF_SUCCESS(status)) {
            SYSTEMTIME st;
            FILETIME ft;
            GetSystemTime(&st);
            SystemTimeToFileTime(&st, &ft);
            Wdf_SetPropertyItemTime(pset, _T("Time"), *(uint64_t *)&ft);
        }
        /* end of windows specific code */
        if (WDF_SUCCESS(status)) {
            switch (map->type) {
            case Map_IntensityAtPoint:
                _stprintf_s(sz, 80, _T("Intensity At Point %.2f"), map->point[0].point);
                status = Wdf_SetPropertyItemInt(pset, _T("MapType"), 1);
                break;
            case Map_SignalToBaseline:
                _stprintf_s(sz, 80, _T("Signal To Baseline From %.2f To %.2f"), map->point[0].point, map->point[1].point);
                status = Wdf_SetPropertyItemInt(pset, _T("MapType"), 2);
                break;
            case Map_SignalToAxis:
                _stprintf_s(sz, 80, _T("Signal To Axis From %.2f To %.2f"), map->point[0].point, map->point[1].point);
                status = Wdf_SetPropertyItemInt(pset, _T("MapType"), 4);
                break;
            default:
                _stprintf_s(sz, 80, _T("Error - unknown map type"));
            }
            if (WDF_SUCCESS(status))
                status = Wdf_SetPropertyItemString(pset, _T("Label"), sz);
        }

        /* convert the pset into a stream and find the size required for the block */
        if (WDF_SUCCESS(status))
        {
            status = Wdf_CreateStream(0, &stream);
            if (WDF_SUCCESS(status))
                status = Wdf_SavePropertySet(pset, stream);
            if (WDF_SUCCESS(status))
                status = Wdf_Tell(stream, &pset_size);
            if (WDF_SUCCESS(status))
                status = Wdf_Seek(stream, 0, SEEK_SET);
            Wdf_ClosePropertySet(pset);
        }
    }

    /* now write the map data to a file block */
    if (WDF_SUCCESS(status))
    {
        uint32_t uid = 0;
        uint64_t size = 0;
        WDF_STREAM fstream = NULL;

        size = (sizeof(uint32_t) * 2) + pset_size + sizeof(uint64_t) + (map->count * sizeof(float));
        status = get_next_map_uid(handle, &uid);
        if (WDF_SUCCESS(status))
            status = Wdf_CreateSection(handle, WDF_BLOCKID_MAP, uid, size, &fstream);
        if (WDF_SUCCESS(status))
        {
            int cb = 0;
            uint32_t x[2] = {WDF_STREAM_IS_PSET, (uint32_t) pset_size};
            status = Wdf_Write(fstream, x, sizeof(x), &cb);
            if (WDF_SUCCESS(status)) {
                char buffer[4096];
                cb = sizeof(buffer);
                while (cb == sizeof(buffer)) {
                    Wdf_Read(stream, buffer, sizeof(buffer), &cb);
                    Wdf_Write(fstream, buffer, cb, &cb);
                }
            }
            if (WDF_SUCCESS(status))
                status = Wdf_Write(fstream, &map->count, sizeof(map->count), &cb);
            if (WDF_SUCCESS(status))
                status = Wdf_Tell(fstream, &map->dataOffset);
            if (WDF_SUCCESS(status))
                map->dataStream = fstream; /* note: moved stream to the map structure */
            else
                Wdf_CloseStream(fstream);
        }
    }
    if (stream != NULL)
        Wdf_CloseStream(stream);
    return status;
}

int
_tmain(int argc, TCHAR *argv[])
{
    WDF_HANDLE handle = NULL;
    WDF_STATUS status = WDF_OK;
    WdfHeader hdr = {0};
    MapMode map_mode = Map_IntensityAtPoint;
    LARGE_INTEGER freq, t[3];
    uint64_t nspectra = 0;

    if (argc < 3) {
        _ftprintf(stderr, _T("usage: wdf_map filename -maptype ?arg arg...?\n"));
        return 1;
    }

    if (_tcscmp(_T("-intensityatpoint"), argv[2]) == 0) {
        map_mode = Map_IntensityAtPoint;
    } else if (_tcscmp(_T("-signaltoaxis"), argv[2]) == 0) {
        map_mode = Map_SignalToAxis;
    } else if (_tcscmp(_T("-signaltobaseline"), argv[2]) == 0) {
        map_mode = Map_SignalToBaseline;
    } else {
        _ftprintf(stderr, _T("invalid mapping mode \"%s\": must be one of ")
                          _T("-intensityatpoint, -signaltoaxis or -signaltobaseline\n"), argv[2]);
        return 1;
    }

    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t[0]);
    QueryPerformanceCounter(&t[1]);

    status = Wdf_Open(argv[1], _T("r+"), &handle);
    if (WDF_SUCCESS(status))
    {
        WdfHeader hdr = {0};
        status = Wdf_GetHeader(handle, &hdr);
        if (WDF_SUCCESS(status))
        {
            nspectra = hdr.nspectra;
            if (hdr.nspectra < 2)
            {
                _ftprintf(stderr, _T("error: not a multifile\n"));
            }
            else
            {
                float *xlist = (float *)malloc(sizeof(float) * hdr.xlistcount);
                if (xlist)
                {
                    status = Wdf_GetXList(handle, 0, -1, xlist);
                    if (WDF_SUCCESS(status))
                    {
                        size_t map_size = sizeof(map_data);// + (sizeof(float) * (uint32_t)hdr.nspectra);
                        map_data *map = malloc(map_size);
                        memset(map, 0, map_size);
                        map->type = map_mode;
                        map->count = hdr.nspectra;
                        map->xlist = xlist;
                        map->xlist_len = hdr.xlistcount;
                        status = get_map_point(map->xlist, map->xlist_len, _tcstod(argv[3], NULL), &map->point[0]);
                        if (WDF_SUCCESS(status)) {
                            if (map_mode == Map_SignalToAxis || map_mode == Map_SignalToBaseline)
                            {
                                if (argc != 5) {
                                    _ftprintf(stderr, _T("usage: wdf_map filename -signalto* point1 point2\n"));
                                    status = WDF_ERROR;
                                }
                                if (WDF_SUCCESS(status))
                                    status = get_map_point(map->xlist, map->xlist_len, _tcstod(argv[4], NULL), &map->point[1]);
                                if (WDF_SUCCESS(status))
                                {
                                    /* swap points if necessary to make the indices increment */
                                    if (map->point[1].index_left < map->point[0].index_left)
                                    {
                                        map_point_t tmp = map->point[0];
                                        map->point[0] = map->point[1];
                                        map->point[1] = tmp;
                                    }
                                    map->buffer_len = map->point[1].index_right - map->point[0].index_left + 1;
                                    map->buffer = (float *)malloc(sizeof(float) * map->buffer_len);
                                    memset(map->buffer, 0, sizeof(float) * map->buffer_len);

                                    _tprintf(_T("Map points at %.3f,%.3f [%d,%d..%d,%d] {%.3f,%.3f..%.3f,%.3f}\n"),
                                        map->point[0].point, map->point[1].point,
                                        map->point[0].index_left, map->point[0].index_right,
                                        map->point[1].index_left, map->point[1].index_right,
                                        map->point[0].xleft, map->point[0].xright,
                                        map->point[1].xleft, map->point[1].xright);
                                }
                            }
                            else
                            {
                                _tprintf(_T("Map point at %.3f [%d,%d] {%.3f,%.3f}\n"),
                                    map->point[0].point,
                                    map->point[0].index_left, map->point[0].index_right,
                                    map->point[0].xleft, map->point[0].xright);
                            }
                        }
                        if (WDF_SUCCESS(status))
                            status = save_map(handle, map);
                        if (WDF_SUCCESS(status)) {
                            WdfEnumSpectraProc fn = (map_mode == Map_IntensityAtPoint) ? mapPointProc : mapIntegratedSignal;
                            status = Wdf_EnumSpectra(handle, fn, (void *)map);
                        }
                        if (map && map->dataStream != NULL)
                            Wdf_CloseStream(map->dataStream);
                        if (map && map->buffer)
                            free(map->buffer);
                        if (map)
                            free(map);
                    }
                }
                free(xlist);
            }
        }
        Wdf_Close(handle);
    }

    QueryPerformanceCounter(&t[2]);
    if (WDF_SUCCESS(status))
    {
        uint64_t ohd;
        double df, dt, ms, dr;
        struct _stati64 sb = {0};
        ohd = t[1].QuadPart - t[0].QuadPart;
        dt = (double)(t[2].QuadPart - t[1].QuadPart - ohd);
        df = (double)freq.QuadPart;
        ms = dt/(df / 1000.0);
        _stati64(argv[1], &sb);
        dr = (sb.st_size / 1048576.0) / (ms / 1000.0);
        printf("%.3f ms %.3f spectra/ms data rate %.3f MB/s\n", ms, nspectra/ms, dr);
    }
    if (!WDF_SUCCESS(status)) {
        _ftprintf(stderr, _T("error %08x: failed to create map\n"), status);
        return 1;
    }
    return 0;
}
