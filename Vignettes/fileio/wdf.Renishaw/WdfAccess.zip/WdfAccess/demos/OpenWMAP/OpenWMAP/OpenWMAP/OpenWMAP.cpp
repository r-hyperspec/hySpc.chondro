 /* OpenWMAP - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * OpenWMAP.cpp : Defines the entry point for the console application.
 */

#include "stdafx.h"
#include <wdfapi.h>

#pragma comment(lib, "wdf")

int _tmain(int argc, _TCHAR* argv[])
{
    // Open .wdf file
    WDF_HANDLE handle;
    WDF_STATUS status = Wdf_Open(L"example.wdf", L"r", &handle); 
    if (WDF_SUCCESS(status))
    {
        // Open map aread blcok
        WdfBlock block;
        WDF_STREAM stream;
        status = Wdf_OpenSection(handle, WDF_BLOCKID_MAPAREA, WDF_BLOCKID_ANY, &stream, &block);
        if (WDF_SUCCESS(status))
        {
            uint32_t flags;
            uint32_t unused;
            float location[3];
            float stepsize[3];
            uint32_t length[3];
            uint32_t lf_size;
            // Read out map aread values
            status = Wdf_Read(stream, &flags, sizeof(flags), NULL);
            if (WDF_SUCCESS(status))
                status = Wdf_Read(stream, &unused, sizeof(unused), NULL);
            if (WDF_SUCCESS(status))
                status = Wdf_Read(stream, location, sizeof(float)*3, NULL);
            if (WDF_SUCCESS(status))
                status = Wdf_Read(stream, stepsize, sizeof(float)*3, NULL);
            if (WDF_SUCCESS(status))
                status = Wdf_Read(stream, length, sizeof(uint32_t)*3, NULL);
            if (WDF_SUCCESS(status))
                status= Wdf_Read(stream, &lf_size, sizeof(lf_size), NULL);
            Wdf_CloseStream(stream);
        }
        Wdf_Close(handle);
    }
	return 0;
}

