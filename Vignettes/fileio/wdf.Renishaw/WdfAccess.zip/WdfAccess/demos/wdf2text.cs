﻿//
// Example program that prints a single spectrum from a WDF data file to the console as ASCII text with
// the xlist values printed in the first column and the spectral intensity in the second column.
// This format is compatible with WiRE's ASCII export/import of spectra.
//
// Compile using:
//   csc /nologo /target:exe /r:WiREDataFormats.dll wdf2text.cs

using System;
using System.Collections.Generic;
using System.Linq;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace wdf2text
{
    public static class Program
    {
        public static int Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("usage: wdf2text filename ?spectrumnumber?");
                return 1;
            }

            long index = 0;
            if (args.Length > 1)
            {
                if (!Int64.TryParse(args[1], out index))
                {
                    Console.WriteLine("error: spectrum number must be a positive integer");
                    return 1;
                }
            }

            using (WdfFile wdf = new WdfFile(args[0], WdfFileAccess.ReadOnly))
            {
                float[] xlist = null;
                float[] ilist = new float[wdf.SpectrumCollection.XListLength];
                wdf.SpectrumCollection.GetXListData(out xlist);
                wdf.SpectrumCollection.GetSpectrum(index, ilist);
                foreach (Tuple<float,float> point in xlist.Zip(ilist, (x, i) => new Tuple<float, float>(x, i)))
                {
                    Console.WriteLine("{0:0.000}\t{1:0.000}", point.Item1, point.Item2);
                }
            }
            return 0;
        }
    }
}
