// Mono test using the Wdf library
//   dmcs -target:exe wdfopen.cs -r:WiREDataFormats.dll
// or use xbuild

using System;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace App
{
    static class Program
    {
        [STAThread]
        static int Main(string[] args)
        {
            int r = 0;
            if (args.Length == 1)
            {
                using (WdfFile wdf = new WdfFile(args[0], WdfFileAccess.ReadOnly))
                {
                    Console.WriteLine("{0} datasets", wdf.SpectrumCollection.Count);
                    Console.WriteLine("{0} capacity", wdf.SpectrumCollection.Capacity);
                }
            }
            else
            {
                Console.WriteLine("usage: wdfopen filename");
            }
            return r;
        }
    }
}
