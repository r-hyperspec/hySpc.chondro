/**
 * @file wdfapi.h
 * @brief Renishaw WiRE Data File format API
 * @author Copyright (c) 2011 Renishaw plc. All rights reserved.
 * @version 1.0
 *
 * Application Programming Interface for the Renishaw wdf file format.
 * This API provides the common interface for accessing and creating WDF files.
 * 
 */

#ifndef WDFAPI_VERSION
#define WDFAPI_VERSION 0x0100

#ifdef __cplusplus
extern "C" {
#endif

#include "wdf.h"
#include <wchar.h>

/**
 * Status codes returned by API functions
 */

typedef enum WDF_STATUS {
    WDF_OK,
    WDF_FAIL,
    WDF_EOF,
    WDF_ERROR,
    WDF_ERROR_INVALID_HANDLE,
    WDF_ERROR_INVALID_ARGUMENT,
    WDF_ERROR_FILE_OPEN,
    WDF_ERROR_INVALID_STREAM,
    WDF_ERROR_STREAM_READ,
    WDF_ERROR_STREAM_WRITE,
    WDF_ERROR_STREAM_SEEK,
    WDF_ERROR_SEEK_MODE,
    WDF_ERROR_INVALID_PSET_HANDLE,
    WDF_ERROR_INVALID_PSET_TYPE,
    WDF_ERROR_PROPERTY_NOT_FOUND,
    WDF_ERROR_SECTION_EXISTS,
    WDF_ERROR_BUFFER_TOO_SMALL,
    WDF_ERROR_OUT_OF_MEMORY,
    WDF_ERROR_OUT_OF_RANGE,
    WDF_ERROR_OUT_OF_DISKSPACE,
    WDF_STATUS_LAST
} WDF_STATUS;

#define WDF_SUCCESS(status) (WDF_OK == (status))

#ifdef STATIC
# define WDFCALL
# define WDFEXPORT
#else
# ifdef _WIN32
#  define WDFCALL __stdcall
#  ifdef WDF_EXPORTS
#   define WDFEXPORT __declspec(dllexport)
#  else
#   define WDFEXPORT __declspec(dllimport)
#  endif /* WDF_EXPORTS */
# else
#  define WDFCALL
#  define WDFEXPORT
# endif /* _WIN32 */
#endif /* WDF_API */
#define WDFAPI WDFEXPORT WDF_STATUS WDFCALL


/** An opaque handle used to represent the opened file for API functions */
typedef struct WDF_HANDLE_ * WDF_HANDLE;
/** An opaque handle used to identify streams within the API */
typedef struct WDF_STREAM_ * WDF_STREAM;
/** An opaque handle used to access property sets */
typedef struct WDF_PSET_   * WDF_PSET;
/** An opaque handle used to manage file change notifications */
typedef struct WDF_OBSERVER_ * WDF_OBSERVER;

/* I'm unsure whether to leave this here as is or hide this and
 * provide access functions - it would be a bit like
 *  WdfGetPropertyInt(prop, &intVal);
 *  WdfChangeType(prop, 'i');
 * etc.
 */
typedef uint16_t pset_key_t;

#pragma pack(push,1)
typedef struct pset_header_t {
    uint8_t type;
    uint8_t flags;
    uint16_t key;
} pset_header_t;
#pragma pack(pop)

typedef struct pset_item_t {
    struct pset_header_t hdr;
    uint32_t size; /* allocated size of this structure */
    uint32_t length; /* length of variable data. ie: length of string data */
    struct pset_item_t *next;
    union {
        int8_t  boolVal;
        int8_t  cVal;
        int16_t hVal;
        int32_t lVal;
        int64_t llVal;
        uint8_t bVal;
        uint16_t uiVal;
        uint32_t ulVal;
        uint64_t ui8;
        float    fltVal;
        double   dblVal;
        uint64_t timeVal;
        float fltVec[1];
        double dblVec[1];
#pragma pack(push,1)
        char strVal[1];
#pragma pack(pop)
    } val;
} pset_item_t;
typedef pset_item_t * WDF_PROPERTY;

/**
 * Function prototype used for @ref Wdf_EnumSections
 *
 * @param[in] handle - a handle to the current file obtained from @ref Wdf_Open
 * @param[in] blockPtr - pointer to the current section header
 * @param[in] clientData - pointer to user declared storage
 * @return Return WDF_OK to continue enumerating sections or WDF_EOF to stop. Any other
 *    return code is handled as an error and halts enumeration and is returned as the result
 *    of the enumeration function.
 */
typedef WDF_STATUS (*WdfEnumSectionProc)(WDF_HANDLE handle, WdfBlock *blockPtr, void *clientData);

/**
 * Function prototype used for @ref Wdf_EnumSpectra
 *
 * A pointer to a function of this type is passed to the enumeration function and is called
 * for each spectrum in the file in turn until a failure code is returned from this function.
 * The caller should pass a pointer to a variable to hold any state that needs to be persisted
 * between calls to each spectra in the clientData parameter.
 *
 * @param[in] handle - a handle to the current file obtained by calling @ref Wdf_Open
 * @param[in] index - index of the current spectrum in the file indicated by the handle parameter.
 * @param[in] clientData - pointer to user declared storage
 * @return Return WDF_OK to continue enumerating sections or WDF_EOF to stop processing. Any other
 *   return code is handled as an error and halts further enumeration and is returned as the result
 *   of the enumeration function.
 */

typedef WDF_STATUS (*WdfEnumSpectraProc)(WDF_HANDLE handle, uint64_t index, void *clientData);

/**
 * Function prototype used for @ref Wdf_EnumProperties
 *
 * @param[in] handle - handle to a property set obtained from @ref Wdf_OpenPropertySet
 * @param[in] prop - pointer to the current property item
 * @param[in] clientData - pointer to user declared storage
 * @return Return WDF_OK to continue enumerating sections or WDF_EOF to stop processing. Any other
 *   return code is handled as an error and halts further enumeration and is returned as the result
 *   of the enumeration function.
 */
typedef WDF_STATUS (*WdfEnumPropertyProc)(WDF_PSET handle, WDF_PROPERTY prop, void *clientData);

/**
 * Open a WDF format file and return an API handle.
 *
 * On Windows there are two versions - one takes a unicode path and mode and the other
 * an ASCII/Multibyte encoded path and mode string. On Unix the strings are expected to be
 * already encoded as UTF-8.
 *
 * @param[in] filename - a NUL terminated string containing the path to the file
 * @param[in] mode - a string containing the open mode (r, w, a, r+ etc)
 * @param[out] handlePtr - pointer to a @ref WDF_HANDLE variable that will contain the API 
 *     handle for use with further API functions.
 * @return WDF_OK on success and sets handlePtr to non-NULL.
 *     If an error occurs the handlePtr will be set to NULL and an error status will be returned.
 */

#ifndef _WIN32
WDFAPI Wdf_Open(const char * filename, const char *mode, WDF_HANDLE *handlePtr);
#else
WDFAPI Wdf_OpenA(const char * filename, const char *mode, WDF_HANDLE *handlePtr);
WDFAPI Wdf_OpenW(const wchar_t * filename, const wchar_t *mode, WDF_HANDLE *handlePtr);
#endif

/**
 * Create a new WDF format file and return an API handle.
 *
 * @param[in] filename - a NUL terminated string containing the path to the file
 * @param[in] nspectra - the maximum number of spectra to be stored in this file
 * @param[in] xlistcount - the length of the xlist
 * @param[in] ylistcount - the length of the ylist
 * @param[out] handlePtr - pointer to a @ref WDF_HANDLE variable that will contain the API
 *    handle for use with further API function calls.
 * @return WDF_OK on success and sets handlePtr to non-NULL.
 *    If an error occurs the handlePtr will be set to NULL and an error status will be returned.
 */

#ifndef _WIN32
WDFAPI Wdf_Create(const char * filename, uint64_t nspectra, uint32_t xlistcount, uint32_t ylistcount, WDF_HANDLE *handlePtr);
#else
WDFAPI Wdf_CreateA(const char * filename, uint64_t nspectra, uint32_t xlistcount, uint32_t ylistcount, WDF_HANDLE *handlePtr);
WDFAPI Wdf_CreateW(const wchar_t * filename, uint64_t nspectra, uint32_t xlistcount, uint32_t ylistcount, WDF_HANDLE *handlePtr);
#endif

/**
 * Close a WDF handle and release any resources associated with the open file.
 *
 * @param[in] handle - a handle previously obtained from @ref Wdf_Open
 * @return The status code is WDF_OK on success.
 */

WDFAPI Wdf_Close(WDF_HANDLE handle);

/**
 * Enumerate the sections of the file calling a user defined function for each section.
 *
 * @param[in] handle - a handle previously obtained from @ref Wdf_Open
 * @param[in] proc - a pointer to a function to be called for each section in turn.
 *     This function should return WDF_FAIL to halt enumeration.
 * @param[in] clientData - a pointer to user data to be passed to the enumeration function.
 * @return WDF_OK on successful completion or WDF_EOF if the enumeration was terminated early by user
 *     defined function. Otherwise any errors are returned and the enumeration
 *     terminated once the error was raised.
 */

WDFAPI Wdf_EnumSections(WDF_HANDLE handle, WdfEnumSectionProc proc, void *clientData);

/**
 * Find a section within the file by its section id and return the file offset and optionally
 * the section header block.
 *
 * @param[in] handle - a handle previously obtained from @ref Wdf_Open
 * @param[in] type - the section type for the section to find
 * @param[in] id - the unique id for the specific section of the given type. This can be set to
 *    WDF_BLOCKID_ANY to indicate that the id parameter is not important and the first section
 *    that matches the type parameter will be returned.
 * @param[out] posPtr - pointer to a variable to hold the file offset of the start of this block
 * @param[out] blockPtr - pointer to a section header. May be NULL.
 * @return WDF_OK on success.
 */

WDFAPI Wdf_FindSection(WDF_HANDLE handle, uint32_t type, uint32_t id, uint64_t *posPtr, WdfBlock *blockPtr);

/**
 * @name Streams
 * Stream functions. Wdf streams permit standard read, write and seek operations on restricted
 * regions of wdf files.
 */

/** @{ */

/**
 * Create a new section in the WDF file and obtain a stream for writing the content.
 * This function appends a new Wdf block of the type specified. The block will contain
 * 'size' bytes of available space which can be accessed using the returned stream.
 *
 * It is an error to attempt to create a section that already exists as determined by a matching
 * id:uid pair. If multiple sections with the same section id are required (eg: MAP sections) then
 * the uid parameter is used to uniquely identify each individual section.
 *
 * @param[in] handle - handle to the file to use as obtained from @ref Wdf_Open or @ref Wdf_Create
 * @param[in] type - section type identifier
 * @param[in] id - unique section identifier (0 if there will only be one section of this type).
 * @param[in] size - size of the section data in bytes.
 * @param[out] streamPtr - variable to hold the WDF_STREAM reference to be used to access the
 *    section data.
 * @return WDF_OK on success; WDF_ERROR_SECTION_EXISTS if the section is not unique.
 */

WDFAPI Wdf_CreateSection(WDF_HANDLE handle, uint32_t type, uint32_t id, uint64_t size, WDF_STREAM *streamPtr);

/**
 * Create a stream based on a section of the file.
 * This an accessor that should keep any data access restricted to the section and
 * provides for alternate implementation (either file i/o or mmap).
 *
 * @param[in] handle - handle to the file to use obtained from @ref Wdf_Open
 * @param[in] type - section type identifier
 * @param[in] id - the unique id for the specific section of the given type. This can be set to
 *    WDF_BLOCKID_ANY to indicate that the id parameter is not important and the first section
 *    that matches the type parameter will be returned.
 * @param[out] streamPtr - pointer to the opened stream or NULL on failure
 * @param[out] blockPtr - pointer to a section header. May be NULL.
 * @return WDF_OK on success
 */

WDFAPI Wdf_OpenSection(WDF_HANDLE handle, uint32_t type, uint32_t id, WDF_STREAM *streamPtr, WdfBlock *blockPtr);

/**
* Create a stream based on a already opened section of the file.
*
* @param[in] handle - handle to the file to use obtained from @ref Wdf_Open
* @param[in] pos - position of the section in the file
* @param[in] blockPtr - pointer to a section header. should not be NULL.
* @param[out] streamPtr - pointer to the opened stream or NULL on failure

* @return WDF_OK on success
*/
WDFAPI Wdf_OpenSectionStream(WDF_HANDLE handle, uint64_t pos, WdfBlock *block, WDF_STREAM *streamPtr);

/**
 * Delete a section.
 * @param[in] handle - handle to the file to use obtained from @ref Wdf_Open
 * @param[in] type - section type identifier
 * @param[in] id - the unique id for the specific section of the given type. This can be set to
 *    WDF_BLOCKID_ANY to indicate that the id parameter is not important and the first section
 *    that matches the type parameter will be affected
 * @return WDF_OK on success
 */

WDFAPI Wdf_DeleteSection(WDF_HANDLE handle, uint32_t type, uint32_t id);

/**
 * Create a stream in memory.
 *
 * @param[in] size - the size of the stream in bytes or 0 to create a dynamically allocated
 *     stream that will grow to accommodate any data written into it.
 * @param[out] streamPtr - pointer to a variable to hold the stream handle.
 * @return WDF_OK on success or WDF_ERROR.
 */

WDFAPI Wdf_CreateStream(uint32_t size, WDF_STREAM *streamPtr);

/**
 * Read data from a stream.
 *
 * @param[in] stream - stream handle as returned by @ref Wdf_OpenSection or @ref Wdf_CreateSection
 * @param[out] buffer - pointer to a buffer to read data from the stream. This will be filled with
 *    bytes from the current stream position up to cbBuffer bytes.
 * @param[in] cbBuffer - number of bytes to read. If the stream length is less than this value
 *    then the pcbRead value will be the number of bytes copied to the buffer.
 * @param[out] pcbRead - pointer to a variable to hold the number of bytes copied into buffer.
 * @return WDF_OK on success
 */

WDFAPI Wdf_Read(WDF_STREAM stream, void *buffer, unsigned int cbBuffer, int *pcbRead);

/**
 * Write data to a stream.
 *
 * @param[in] stream - stream handle as returned by @ref Wdf_OpenSection or @ref Wdf_CreateSection
 * @param[in] buffer - pointer to data to be written to the stream.
 * @param[in] cbBuffer - number of bytes to be written from the data buffer.
 * @param[out] pcbWrote - pointer to a variable to hold the number of bytes copied from the buffer.
 * @return WDF_OK on success
 */

WDFAPI Wdf_Write(WDF_STREAM stream, const void *buffer, unsigned int cbBuffer, int *pcbWrote);

/**
 * Move the current stream position
 *
 * @param[in] stream - the stream to operate upon
 * @param[in] offset - number of bytes to offset the stream position
 * @param[in] seekMode - one of SEEK_SET to set the position as an absolute offset from
 *    the start of the stream; SEEK_CUR to offset from the current stream position;
 *    or SEEK_END to offset from the end of the stream.
 * @return WDF_OK on success;
 *    WDF_ERROR_INVALID_STREAM if the stream is not a WDF stream;
 *    WDF_ERROR_SEEK_MODE if an invalid seekMode parameter value was provided;
 *    WDF_ERROR_STREAM_SEEK if the offset moves the position beyond the ends of the stream.
 */

WDFAPI Wdf_Seek(WDF_STREAM stream, int64_t offset, int seekMode);

/**
 * Get the current position of the stream.
 *
 * @param[in] stream - the stream to be queried
 * @param[out] positionPtr - a pointer to a variable to hold the returned stream position.
 * @return WDF_OK on success
 */

WDFAPI Wdf_Tell(WDF_STREAM stream, uint64_t *positionPtr);

/**
 * Close a stream and release any resources back to the system
 *
 * @param[in] stream - the stream to be closed.
 * @return WDF_OK on success or an error status code.
 */

WDFAPI Wdf_CloseStream(WDF_STREAM stream);

/** @} */

/**
 * Read a range of values for a spectrum from the file.
 *
 * This function can read either a single value or a range of values from a specified
 * spectrum. The start and end parameters are range checked and end can be specified as
 * -1 to obtain all the spectrum values. The buffer to contain the result must be
 * of sufficient size - no spectrum will return more than hdr.npoints values.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open
 * @param[in] index - the 0-based index of the spectrum to read from
 * @param[in] start - the start of the range of values to read (0-based index of the points)
 * @param[in] end - the index of the end of the range of points.
 * @param[out] dataPtr - pointer to a buffer of floats large enough to hold the result
 */

WDFAPI Wdf_SpectrumData(WDF_HANDLE handle, uint64_t index, int32_t start, int32_t end, float *dataPtr);

/**
 * Write a range of new values for a range of a spectrum.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open
 * @param[in] index - the 0-based index of the spectrum to be modified.
 * @param[in] start - the 0-based start the range of values to be modified
 * @param[in] end - the end index of the range to be modified or -1 to indicate the last point.
 * @param[in] data - a pointer to an array of floats to use as the new values.
 * @return WDF_OK
 */

WDFAPI Wdf_SetSpectrumData(WDF_HANDLE handle, uint64_t index,
                                             int32_t start, int32_t end, const float *data);

/**
 * Apply a function over each dataset.
 * The function receives the file handle and the index of the current spectrum along with
 * a pointer to user-provided data. This can be used to generate map results from the spectral data.
 * If the user-defined function returns anything other than WDF_OK then the iteration is canceled and
 * that result returned by this function.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open
 * @param[in] proc - user-defined function called for each spectrum
 * @param[in] clientData - user-defined data passed to the proc function.
 * @return WDF_OK on success or WDF_EOF if the user function caused early termination or
 *    the result of the last proc function called which may be any error code.
 */

WDFAPI Wdf_EnumSpectra(WDF_HANDLE handle, WdfEnumSpectraProc proc, void *clientData);

/**
 * Utility function to obtain the WDF file header structure for an open file.
 *
 * @param[in] handle - a wdf handle obtained from @ref Wdf_Open
 * @param[out] headerPtr - a pointer to a WdfHeader structure to receive the data.
 * @return WDF_OK on success or WDF_ERROR_INVALID_HANDLE if handle is invalid.
 */

WDFAPI Wdf_GetHeader(WDF_HANDLE handle, WdfHeader *headerPtr);

/**
 * Utility function to set a header field for the specified WDF file.
 *
 * This is a general purpose function hence the generic input data type.
 * It will only accept a limited set of fields which are described as offsets
 * into the structure. For instance to update the title field:
 * @code
 * char buf[160];
 * memset(buf, 0, sizeof(buf)); // ensure the buffer is zero filled.
 * strcat(buf, "This is a new title in utf8 encoded text");
 * Wdf_SetField(handle, offsetof(WdfHeader,title), buf, sizeof(buf));
 * @endcode
 *
 * @param[in] handle - a file hanled returned by @ref Wdf_Open
 * @param[in] field - a field offset. eg: offsetof(WdfHeader, fieldname)
 *    Any invalid offset or protected field will result in WDF_ERROR_INVALID_ARGUMENT.
 * @param[in] value - a pointer to the new data for this field
 * @param[in] size - the size of the data pointed to by the value parameter.
 */

WDFAPI Wdf_SetField(WDF_HANDLE handle, int field, void *value, uint32_t size);


/**
 * Read origin data values from the data origin section.
 * The number and type of data origins depends on the type of data acquisition defined
 * when collecting the data but there is only one of any data type.
 *
 * @param[in] handle - a wdf handle obtained from @ref Wdf_Open
 * @param[in] type - one of the @ref WdfDataType enumeration
 * @param[in] start - the start of the value range. 0 for the first point.
 * @param[in] end - the last point of the range. Pass -1 to indicate the whole set. The value of end may
 *   not be less than the value of start.
 * @param[out] dataPtr - a pointer to an array of doubles to hold the returned data.
 * @return WDF_OK on success or an error code from the WDF_STATUS enumeration
 */

WDFAPI Wdf_GetOriginData(WDF_HANDLE handle, WdfDataType type, int start, int end, double *dataPtr);

/**
 * Update origin data values for a specified data origin.
 * @param[in] handle - a wdf handle obtained from @ref Wdf_Open
 * @param[in] type - one of the @ref WdfDataType enumeration
 * @param[in] start - the start of the value range. 0 for the first point.
 * @param[in] end - the last point of the range. Pass -1 to indicate the whole set. The value of
 *    end may not be less than the value of start (except when it is -1).
 * @param[in] dataPtr - a pointer to the new values to be written
 * @return WDF_OK on success or an error code from the WDF_STATUS enumeration.
 */

WDFAPI Wdf_SetOriginData(WDF_HANDLE handle, WdfDataType type, int start, int end, const double *dataPtr);

/**
 * Structure used to declare data origin type and units when creating the origin lists.
 * The type field is used to identify particular data origin lists.
 * The units field expresses the format of the data values.
 */

typedef struct WdfOriginTypeA {
    uint32_t type;  /**< the data origin type; one of the @ref WdfDataType enumeration */
    uint32_t units; /**< the units of the origin values from the @ref WdfDataUnits enumeration */
    int alternate; /**< flag set true to indicate this is an alternate data origin */
    char label[16]; /** < the data origin label; encoded as utf-8 */
} WdfOriginTypeA;

typedef struct WdfOriginTypeW {
    uint32_t type;  /**< the data origin type; one of the @ref WdfDataType enumeration */
    uint32_t units; /**< the units of the origin values from the @ref WdfDataUnits enumeration */
    int alternate; /**< flag set true to indicate this is an alternate data origin */
    wchar_t label[16]; /** < the data origin label; encoded as utf-8 */
} WdfOriginTypeW;

/**
 * Create the data origin section in the file using the number of
 * origins and types and units provided.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open or @ref Wdf_Create
 * @param[in] count - number of data origins defined
 * @param[in] origins - array of @ref WdfOriginType structures that contain one pair of
 *     type and units for each data origin list. The type is used to identify each origin
 *     list and the units value expresses the way the data value has been stored.
 */

WDFAPI Wdf_CreateOriginDataA(WDF_HANDLE handle, uint32_t count, const WdfOriginTypeA origins[]);
WDFAPI Wdf_CreateOriginDataW(WDF_HANDLE handle, uint32_t count, const WdfOriginTypeW origins[]);

/* get origin info for all data origins - pass NULL for prgOriginInfo to get a count only */
WDFAPI Wdf_GetOriginInfoW(WDF_HANDLE handle, uint32_t *pCount, WdfOriginTypeW *prgOriginInfo);
WDFAPI Wdf_GetOriginInfoA(WDF_HANDLE handle, uint32_t *pCount, WdfOriginTypeA *prgOriginInfo);

/**
 * Get the file's shared X-list data.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open
 * @param[in] start - the 0-based start the range of values to be read
 * @param[in] end - the end index of the range to be modified or -1 to indicate the last point
 *   (equivalent to header.xlistcount).
 * @param[in] dataPtr - a pointer to an array to hold the read values.
 */

WDFAPI Wdf_GetXList(WDF_HANDLE handle, int start, int end, float *dataPtr);

/**
 * Set the x-list values.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open
 * @param[in] start - the 0-based start of the range of values to write
 * @param[in] end - the end index of the range to be modified.
 * @param[in] dataPtr - a pointer to an array of values to be written.
 * @return WDF_OK on success.
 */

WDFAPI Wdf_SetXList(WDF_HANDLE handle, int start, int end, const float *dataPtr);

/**
 * Get the file's shared Y-list data.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open
 * @param[in] start - the 0-based start the range of values to be read
 * @param[in] end - the end index of the range to be modified or -1 to indicate the last point
 *   (equivalent to header.npoints).
 * @param[in] dataPtr - a pointer to an array to hold the read values.
 */

WDFAPI Wdf_GetYList(WDF_HANDLE handle, int start, int end, float *dataPtr);

/**
 * Set the y-list values.
 *
 * @param[in] handle - a file handle returned by @ref Wdf_Open
 * @param[in] start - the 0-based start of the range of values to write
 * @param[in] end - the end index of the range to be modified.
 * @param[in] dataPtr - a pointer to an array of values to be written.
 * @return WDF_OK on success.
 */

WDFAPI Wdf_SetYList(WDF_HANDLE handle, int start, int end, const float *dataPtr);


/**
 * @name Observers
 * File notification observer functions.
 *
 * The file observation mechanism permits the user to register a
 * callback to be called when a specified file is modified in some
 * way. Any changes to the timestamp or size of the file or creation
 * or deletion of the file will trigger a notification. These
 * notification events are queued until the program thread becomes
 * alertable so at some point client programs must run a Windows event
 * loop or call SleepEx, WaitForSingleObjectEx or an equivalent
 * function. See the MSDN documentation for ReadDirectoryChanges about
 * this.  The Windows API monitors directories, but the directory
 * level notifications are filtered for specific notifications
 * relevant to the registered files permitting a callback per file to
 * be registered if desired.
 */

/** @{ */

/**
 * Function prototype used to declare a user function for use with @ref Wdf_ObserverAdd
 *
 * @param[in] action - the event code for the event triggering this call
 * @param[in] path - the full path for the file that triggered this call
 * @param[in] clientData - pointer to the user-defined data registered with this callback
 * @return The return value is ignored.
 */
typedef WDF_STATUS (*WdfObserverCallback)(int action, const wchar_t *path, void *clientData);

/**
 * Function registered to clean any resources associated with the clientData that can
 * be registered when calling @ref Wdf_ObserverAdd.
 *
 * This callback function is passed the user's pointer before the library data associated
 * with a notification registration is destroyed. Once this callback returns no further
 * references will be made to the clientData or to the callback functions registered
 * by the previous call to @ref Wdf_ObserverAdd.
 *
 * @param[in] clientData - pointer to the user-defined data to be released.
 */
typedef void (*WdfObserverCleanup)(void *clientData);

/**
 * Create an observer element for managing file notification handlers.
 *
 * Windows provides directory level file change notifications and we are interested
 * in file change notifications. This manager object keeps track of which directories
 * are currently being observed and when triggered only notifications for registered
 * files will cause their callback functions to be called.
 *
 * @param[out] handlePtr - pointer to a location to store the observer handle.
 *    This handle is required for all other observer functions.
 * @return WDF_OK on success or WDF_ERROR for failure.
 */

WDFAPI Wdf_ObserverCreate(WDF_OBSERVER *handlePtr);

/**
 * Delete an observer and free all resources associated with the managed observations.
 *
 * The directory notification objects associated with this manager object are each destroyed
 * along with all individual file observers. If any file observer has client data and a cleanup
 * function then the cleanup function is called to permit user code to release custom resources
 * before the observer item is deleted.
 *
 * @param[in] handle - an observer handle created previously with @ref Wdf_ObserverCreate.
 */

WDFAPI Wdf_ObserverDestroy(WDF_OBSERVER handle);

/**
 * Register a callback function to be called when changes to a specified file occur.
 *
 * This function registers a file path with a WDF_OBSERVER manager such that when changes
 * are made to the file the user-defined callback function is called with the optional clientData
 * passed in (see @ref WdfObserverCallback). The changes that are monitored are file creation, file
 * deletion and file modification (size or timestamp changed).
 *
 * A cleanup function may also be registered to be called when this object is destroyed after a call
 * to either @ref Wdf_ObserverDestroy or @ref Wdf_ObserverRemove. This enables custom cleanup of the
 * clientData parameter if required. See @ref WdfObserverCleanup for the function prototype.
 *
 * @param[in] handle - an observer handle created by @ref Wdf_ObserverCreate
 * @param[in] path - the path to the file of interest. This does not need to exist but the parent
 *   directory must exist and the whole must be a valid path.
 * @param[in] callback - function to be called when the specified file is modified.
 * @param[in] clientData - a pointer to user data passed to the callback function. May be NULL.
 * @param[in] cleanup - a function that will be called when the notification is destroyed to allow
 *    user code to clean up any resources associated with the clientData parameter. May be NULL.
 * @return The status code will be WDF_OK on success or WDF_ERROR_INVALID_ARGUMENT if there
 *   is a problem with the provided arguments (eg: directory path invalid).
 */

#ifndef _WIN32
WDFAPI Wdf_ObserverAdd(WDF_OBSERVER handle, const char *path,
    WdfObserverCallback callback, void *clientData, WdfObserverCleanup cleanup);
#else
WDFAPI Wdf_ObserverAddA(WDF_OBSERVER handle, const char *path,
    WdfObserverCallback callback, void *clientData, WdfObserverCleanup cleanup);
WDFAPI Wdf_ObserverAddW(WDF_OBSERVER handle, const wchar_t *path,
    WdfObserverCallback callback, void *clientData, WdfObserverCleanup cleanup);
#endif

/**
 * Remove a previously registered file from the file change notification observer manager.
 *
 * @param[in] handle - an observer handle created by @ref Wdf_ObserverCreate
 * @param[in] path - the path to the file as originally passed to @ref Wdf_ObserverAdd
 * @return WDF_OK on success
 */

#ifndef _WIN32
WDFAPI Wdf_ObserverRemove(WDF_OBSERVER handle, const char *path);
#else
WDFAPI Wdf_ObserverRemoveA(WDF_OBSERVER handle, const char *path);
WDFAPI Wdf_ObserverRemoveW(WDF_OBSERVER handle, const wchar_t *path);
#endif

/** @} */

/**
 * @name PropertySet
 * PropertySet manipulation functions.
 */
/** @{ */

/**
 * Create an empty property set
 *
 * @param[out] handlePtr - pointer to a variable to hold the property set handle.
 */

WDFAPI Wdf_CreatePropertySet(WDF_PSET *handlePtr);

/**
 * Load a property set from a stream.
 *
 * @param[in] stream -
 * @param[in] size -
 * @param[out] handlePtr -
 */

WDFAPI Wdf_OpenPropertySet(WDF_STREAM stream, uint64_t size, WDF_PSET *handlePtr);

/**
 * Access a nested property set contained within a parent pset.
 *
 * @param[in] parent - handle of the parent pset
 * @param[in] item - pointer to the pset item holding the child data
 * @param[out] handlePtr - pointer to a variable to hold the child property set handle.
 */

WDFAPI Wdf_OpenChildPropertySet(WDF_PSET parent, pset_item_t *item, WDF_PSET *handlePtr);

/**
 * Close a property set.
 * 
 * This does not save the property set - it just releases any resources allocated.
 *
 * @param[in] handle - handle to a property set created by @ref Wdf_OpenPropertySet
 * @return WDF_OK on success.
 */

WDFAPI Wdf_ClosePropertySet(WDF_PSET handle);

/**
 * Iterate over all the properties of a property set calling a user defined function for each in turn.
 *
 * @param[in] handle - handle to a property set created by @ref Wdf_OpenPropertySet
 * @param[in] proc - user defined function matching the @ref WdfEnumPropertyProc prototype. This
 *    is called with the current property and the user provided clientData pointer for every property.
 * @param[in] clientData - a pointer to user provided data to be passed to the callback function
 * @return WDF_OK on success or WDF_EOF if the enumeration was terminated early or an error code
 *    returned from the user-defined enumeration function.
 */

WDFAPI Wdf_EnumProperties(WDF_PSET handle, WdfEnumPropertyProc proc, void *clientData);

WDFAPI Wdf_SavePropertySet(WDF_PSET handle, WDF_STREAM stream);


#ifndef _WIN32

/**
 * Get a property value from a property set by name.
 * Properties are owned by the pset and are released when the pset is destroyed.
 * When accessing a property, the client receives a pointer to the item in the pset but
 * should not attempt to free the property item itself.
 *
 * @param[in] handle - handle of the propertyset containing this item.
 * @param[in] name - pointer to the name of the property
 * @param[out] propPtr - pointer to a variable to hold the address of the property data.
 */

WDFAPI Wdf_GetPropertyItem(WDF_PSET handle, const char *name, WDF_PROPERTY *propPtr);

/**
 * Set a property in a property set.
 * If a property with this name already exists in the property set then it is updated otherwise a
 * new property is added to the set.
 * @param[in] handle - handle to the property set
 * @param[in] name - name of the property
 * @param[in] propPtr - a pointer to a prepared pset_item_t structure.
 */

WDFAPI Wdf_SetPropertyItem(WDF_PSET handle, const char *name, const WDF_PROPERTY propPtr);

/**
 * Get the property key name for a property item.
 * Properties are stored using a numeric key value generated from the property name. This function
 * does a reverse lookup to retrieve the name used for storing the property.
 * @param[in] handle - handle of the propertyset containing this item.
 * @param[in] item - the property item for which to find the name
 * @param[out] szName - pointer to a buffer to hold the property name string
 * @param[in] cchName - the size of the name buffer in characters
 */
WDFAPI Wdf_GetPropertyName(WDF_PSET handle, const WDF_PROPERTY item, char *name, unsigned int len);

#else
WDFAPI Wdf_GetPropertyItemA(WDF_PSET handle, const char *name, WDF_PROPERTY *propPtr);
WDFAPI Wdf_SetPropertyItemA(WDF_PSET handle, const char *name, const WDF_PROPERTY propPtr);
WDFAPI Wdf_GetPropertyNameA(WDF_PSET handle, const WDF_PROPERTY item, char *name, unsigned int cchName);
WDFAPI Wdf_GetPropertyItemW(WDF_PSET handle, const wchar_t *name, WDF_PROPERTY *propPtr);
WDFAPI Wdf_SetPropertyItemW(WDF_PSET handle, const wchar_t *name, const WDF_PROPERTY propPtr);
WDFAPI Wdf_GetPropertyNameW(WDF_PSET handle, const WDF_PROPERTY item, wchar_t *name, unsigned int cchName);
#endif

WDFAPI Wdf_SetPropertyItemIntW(WDF_PSET pset, const wchar_t *key, const int value);
WDFAPI Wdf_SetPropertyItemIntA(WDF_PSET pset, const char *key, const int value);
WDFAPI Wdf_SetPropertyItemBoolW(WDF_PSET pset, const wchar_t *key, const int value);
WDFAPI Wdf_SetPropertyItemBoolA(WDF_PSET pset, const char *key, const int value);
WDFAPI Wdf_SetPropertyItemShortW(WDF_PSET pset, const wchar_t *key, const short value);
WDFAPI Wdf_SetPropertyItemShortA(WDF_PSET pset, const char *key, const short value);
WDFAPI Wdf_SetPropertyItemFloatW(WDF_PSET pset, const wchar_t *key, const float value);
WDFAPI Wdf_SetPropertyItemFloatA(WDF_PSET pset, const char *key, const float value);
WDFAPI Wdf_SetPropertyItemFloatVectorW(WDF_PSET pset, const wchar_t *key, uint32_t count, const float *value);
WDFAPI Wdf_SetPropertyItemFloatVectorA(WDF_PSET pset, const char *key, uint32_t count, const float *value);
WDFAPI Wdf_SetPropertyItemDoubleW(WDF_PSET pset, const wchar_t *key, const double value);
WDFAPI Wdf_SetPropertyItemDoubleA(WDF_PSET pset, const char *key, const double value);
WDFAPI Wdf_SetPropertyItemWideW(WDF_PSET pset, const wchar_t *key, const uint64_t value);
WDFAPI Wdf_SetPropertyItemWideA(WDF_PSET pset, const char *key, const uint64_t value);
WDFAPI Wdf_SetPropertyItemTimeW(WDF_PSET pset, const wchar_t *key, const uint64_t value);
WDFAPI Wdf_SetPropertyItemTimeA(WDF_PSET pset, const char *key, const uint64_t value);
WDFAPI Wdf_SetPropertyItemStringW(WDF_PSET pset, const wchar_t *key, const wchar_t *value);
WDFAPI Wdf_SetPropertyItemStringA(WDF_PSET pset, const char *key, const char *value);
WDFAPI Wdf_SetPropertyItemPsetW(WDF_PSET pset, const wchar_t *key, const WDF_PSET child);
WDFAPI Wdf_SetPropertyItemPsetA(WDF_PSET pset, const char *key, const WDF_PSET child);

/** @} */

#ifdef NOT_IMPLEMENTED_YET /* ------------------------------------------------------ */

/* utility functions */
int Wdf_WideToUTF8(const wchar_t *, int, char *);
int Wdf_Utf8ToWide();

#endif /* NOT IMPLEMENTED YET * --------------------------------------------------- */

/* Support the standard Windows dual-encoding string option */
#ifdef _WIN32
#  ifdef UNICODE
#    define Wdf_Open             Wdf_OpenW
#    define Wdf_Create           Wdf_CreateW
#    define Wdf_GetPropertyName  Wdf_GetPropertyNameW
#    define Wdf_GetPropertyItem  Wdf_GetPropertyItemW
#    define Wdf_SetPropertyItem  Wdf_SetPropertyItemW
#    define Wdf_ObserverAdd      Wdf_ObserverAddW
#    define Wdf_ObserverRemove   Wdf_ObserverRemoveW
#    define Wdf_SetPropertyItemInt Wdf_SetPropertyItemIntW
#    define Wdf_SetPropertyItemBool Wdf_SetPropertyItemBoolW
#    define Wdf_SetPropertyItemShort Wdf_SetPropertyItemShortW
#    define Wdf_SetPropertyItemWide Wdf_SetPropertyItemWideW
#    define Wdf_SetPropertyItemTime Wdf_SetPropertyItemTimeW
#    define Wdf_SetPropertyItemFloat Wdf_SetPropertyItemFloatW
#    define Wdf_SetPropertyItemDouble Wdf_SetPropertyItemDoubleW
#    define Wdf_SetPropertyItemString Wdf_SetPropertyItemStringW
#    define Wdf_SetPropertyItemPset Wdf_SetPropertyItemPsetW
#    define Wdf_SetPropertyItemFloatVector Wdf_SetPropertyItemFloatVectorW
#    define WdfOriginType WdfOriginTypeW
#    define Wdf_CreateOriginData Wdf_CreateOriginDataW
#    define Wdf_GetOriginInfo    Wdf_GetOriginInfoW
#  else
#    define Wdf_Open             Wdf_OpenA
#    define Wdf_Create           Wdf_CreateA
#    define Wdf_GetPropertyName  Wdf_GetPropertyNameA
#    define Wdf_GetPropertyItem  Wdf_GetPropertyItemA
#    define Wdf_SetPropertyItem  Wdf_SetPropertyItemA
#    define Wdf_ObserverAdd      Wdf_ObserverAddA
#    define Wdf_ObserverRemove   Wdf_ObserverRemoveA
#    define Wdf_SetPropertyItemInt Wdf_SetPropertyItemIntA
#    define Wdf_SetPropertyItemBool Wdf_SetPropertyItemBoolA
#    define Wdf_SetPropertyItemShort Wdf_SetPropertyItemShortA
#    define Wdf_SetPropertyItemWide Wdf_SetPropertyItemWideA
#    define Wdf_SetPropertyItemTime Wdf_SetPropertyItemTimeA
#    define Wdf_SetPropertyItemFloat Wdf_SetPropertyItemFloatA
#    define Wdf_SetPropertyItemDouble Wdf_SetPropertyItemDoubleA
#    define Wdf_SetPropertyItemString Wdf_SetPropertyItemStringA
#    define Wdf_SetPropertyItemPset Wdf_SetPropertyItemPsetA
#    define Wdf_SetPropertyItemFloatVector Wdf_SetPropertyItemFloatVectorA
#    define WdfOriginType WdfOriginTypeA
#    define Wdf_CreateOriginData Wdf_CreateOriginDataA
#    define Wdf_GetOriginInfo    Wdf_GetOriginInfoA
#  endif /* !UNICODE */
#endif /* !_WIN32 */

#ifdef __cplusplus
}
#endif

#endif /* WDFAPI_VERSION */
