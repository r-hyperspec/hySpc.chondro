﻿/* 
 * OpenOrigin - Copyright (c) 2013 Renishaw plc. All rights reserved.
 * 
 * This demo file shows how to open a .wdf file and extrac the origin data
 * from within using C#
 * 
 * Ensure that WiREDataFormats.dll has been referenced. Create a variable of
 * type WdfFile with parameters for file name and access rights. In this demo
 * the file name is taken from the first command line argument.
 * 
 * In this example the WdfFile variable is used to extract origin data which is
 * then printed to the screen.
 */

using System;
using System.IO;
using Renishaw.SPD.WiRE.WiREDataFormats;

namespace OpenOrigin
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                string fileName = args[0];
                using (WdfFile file = new WdfFile(fileName, WdfFileAccess.ReadOnly))
                {
                    WdfSpectrumCollection spectrum = file.SpectrumCollection;
                    long length = spectrum.Count;
                    double[] data = new double[length];
                    WiREDataOriginListCollection originList = spectrum.DataOrigins;
                    //Choose the Origin type you wish to retrieve here
                    WiREDataType type = WiREDataType.SpatialX;
                    //checks if origin with this type is even present
                    bool bHasType = originList.ContainsListWithDataType(type);
                    if (bHasType)
                    {
                        int i = 0;
                        IWiREDataOriginList origin = originList.GetByIndex(i);
                        //Loops through origins to get the origin with the correct type.
                        for (i = 0; i < originList.Count; i++)
                        {
                            //Returns the ith Origin list (zero based)
                            origin = originList.GetByIndex(i);
                            if (origin.DataType == type)
                                break;
                        }

                        // Read origin data
                        /*
                         * IWiREDataOriginList::ReadRange(long firstElement, double[] array, int offset, int count)
                         * firstElement: the zero based index of the first element to retrieve
                         * array: An array to copy the requested data into
                         * offset: The zero based index at which to start copying data into
                         * count: The number of elements to retrieve.
                         */
                        origin.ReadRange(0, data, 0, (int)length);

                        for (i = 0; i < length; i++)
                        {
                            Console.WriteLine(data[i]);
                        }
                    }
                }
            }
        }
    }
}
