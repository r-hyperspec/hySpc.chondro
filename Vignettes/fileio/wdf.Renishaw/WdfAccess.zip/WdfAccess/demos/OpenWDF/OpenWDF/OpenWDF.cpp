/* OpenWDF - Copyright (c) 2013 Renishaw plc. All rights reserved.
 *
 * Sample program to show how to open a WDF file and access it's contents
 */

#include <wdfapi.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#pragma comment(lib, "wdf")

static const char *version = "4.0.0.1";

//This function is called by Wdf_EnumSections on each block in the file. blockPtr will point to the current block's 
//header, and clientdata will point to whatever data structure was passed into clientdata in Wdf_EnumSections
WDF_STATUS exampleproc(WDF_HANDLE handle, WdfBlock *blockPtr, void *clientData)
{
    if (blockPtr->id == WDF_BLOCKID_DATA)
        printf("Contains a data block");
    return WDF_OK;
}

int main()
{
    WDF_HANDLE handle=NULL;
    WdfHeader hdr = {0};
    /*
     * Wdf_Open(BSTR filename, BSTR mode, WDF_HANDLE* phandle)
     * filename: path of file to be opened
     * mode: BSTR containing the read mode, (same as for fopen)
     * [ret] phandle: pointer to handle to be returned 
     */
    WDF_STATUS status = Wdf_Open(L"example.wdf", L"r", &handle);
    if (WDF_SUCCESS(status))
    {
        //Runs the function passed in on each block in the file
        /*
         * Wdf_EnumSections(WDF_HANDLE handle, WdfEnumSectionProc* function, void* clientdata)
         * handle: handle to file to enumerate
         * function: function to call on each block (WdfEnumSectionProc is defined in wdfapi.h)
         * clientdata: pointer to data that can be declared before the call, and updated in each call of function. 
         */
        status = Wdf_EnumSections(handle, exampleproc, NULL);
        if (WDF_SUCCESS(status))
        {
            WDF_STREAM stream;
            WdfBlock block;
            //Opens a WDF_STREAM immediately after the block header. The block header which has it's address passed 
            //in will have it's internal data overwritten to as a copy of the sections header. In the event of there
            //being two blocks with the same type, the first block of that type will be opened. One can pass in
            //the uid of the block one wants to open as the third argument instead of WDF_BLOCKID_ANY.
            status = Wdf_OpenSection(handle, WDF_BLOCKID_DATA, WDF_BLOCKID_ANY, &stream, &block);
            if (WDF_SUCCESS(status))
            {
                //copies data from the file header into the WdfHeader structure specified.
                status = Wdf_GetHeader(handle, &hdr);
                if (WDF_SUCCESS(status))
                {
                    //Gets the size of the block from the block header and finds the size of the data inside the block (without the block header)
                    uint32_t dataSize = block.size - sizeof(block);
                    float *data = new float[dataSize];
                    //Reads the stream into a user defined buffer
                    status = Wdf_Read(stream, data, dataSize, NULL);
                    if (WDF_SUCCESS(status))
                    {
                        WDF_STREAM newStream;
                        //Creates a stream
                        status = Wdf_CreateStream(dataSize, &newStream);
                        if (WDF_SUCCESS(status))
                        {
                            //Writes into a stream.
                            status = Wdf_Write(newStream, data, dataSize, NULL);
                            Wdf_CloseStream(newStream);
                        }
                    }
                    delete [] data;
                }
                //Always close streams when finished using them
                Wdf_CloseStream(stream);
            }
        }
        //Always close files when no longer using them. 
        Wdf_Close(handle);
    }
    return 0;
}